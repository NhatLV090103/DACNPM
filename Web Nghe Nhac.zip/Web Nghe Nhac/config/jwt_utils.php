<?php
// Định nghĩa secret key cho JWT
define('JWT_SECRET_KEY', '4vLVX9M8Z2kN7WqF'); // Thay đổi key này trong môi trường production

class JWT {
    private static $alg_supported = ['HS256'];
    
    public static function encode($payload, $key, $alg = 'HS256') {
        if (!in_array($alg, self::$alg_supported)) {
            throw new Exception('Algorithm not supported');
        }
        
        $header = json_encode(['typ' => 'JWT', 'alg' => $alg]);
        $header = self::base64url_encode($header);
        
        $payload = json_encode($payload);
        $payload = self::base64url_encode($payload);
        
        $signature = hash_hmac('sha256', "$header.$payload", $key, true);
        $signature = self::base64url_encode($signature);
        
        return "$header.$payload.$signature";
    }
    
    public static function decode($token, $key, $verify = true) {
        $parts = explode('.', $token);
        
        if (count($parts) != 3) {
            throw new Exception('Wrong number of segments');
        }
        
        list($header, $payload, $signature) = $parts;
        
        $header = json_decode(self::base64url_decode($header));
        if (!$header) {
            throw new Exception('Invalid header encoding');
        }
        
        $payload = json_decode(self::base64url_decode($payload));
        if (!$payload) {
            throw new Exception('Invalid payload encoding');
        }
        
        if ($verify) {
            if (empty($header->alg)) {
                throw new Exception('Empty algorithm');
            }
            
            if (!in_array($header->alg, self::$alg_supported)) {
                throw new Exception('Algorithm not supported');
            }
            
            // Verify signature
            $sig = self::base64url_decode($signature);
            $expected = hash_hmac('sha256', "$header.$payload", $key, true);
            
            if ($sig !== $expected) {
                throw new Exception('Signature verification failed');
            }
            
            // Verify expiration
            if (isset($payload->exp) && time() >= $payload->exp) {
                throw new Exception('Token has expired');
            }
        }
        
        return $payload;
    }
    
    private static function base64url_encode($data) {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }
    
    private static function base64url_decode($data) {
        return base64_decode(strtr($data, '-_', '+/'));
    }
} 