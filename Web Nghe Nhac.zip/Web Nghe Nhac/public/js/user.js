// Hàm quản lý session
const SessionManager = {
    // Thời gian token hết hạn (24 giờ)
    TOKEN_EXPIRY: 24 * 60 * 60 * 1000,

    // Lưu thông tin đăng nhập
    setSession(userData) {
        const session = {
            userId: userData.userId,
            username: userData.username,
            token: userData.token,
            expiresAt: Date.now() + this.TOKEN_EXPIRY
        };
        
        // Lưu vào sessionStorage để session tự động xóa khi đóng tab
        sessionStorage.setItem('userSession', JSON.stringify(session));
        
        // Lưu token vào cookie với httpOnly nếu cần
        if (userData.token) {
            document.cookie = `auth_token=${userData.token}; path=/; max-age=${this.TOKEN_EXPIRY/1000}; SameSite=Strict`;
        }
    },

    // Kiểm tra session hiện tại
    getSession() {
        const sessionData = sessionStorage.getItem('userSession');
        if (!sessionData) return null;

        const session = JSON.parse(sessionData);
        
        // Kiểm tra hết hạn
        if (Date.now() > session.expiresAt) {
            this.clearSession();
            return null;
        }

        return session;
    },

    // Xóa session khi đăng xuất
    clearSession() {
        sessionStorage.removeItem('userSession');
        localStorage.removeItem('userId');
        localStorage.removeItem('userName');
        document.cookie = 'auth_token=; path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT';
    },

    // Làm mới session
    refreshSession() {
        const session = this.getSession();
        if (session) {
            session.expiresAt = Date.now() + this.TOKEN_EXPIRY;
            sessionStorage.setItem('userSession', JSON.stringify(session));
        }
    }
};

// Cập nhật hàm handleLogin
const LoginHandler = {
    async handleLogin(event) {
        if (event) {
            event.preventDefault();
        }

        const loginUser = document.getElementById('loginUser');
        const loginPass = document.getElementById('loginPass');
        const loginModal = document.getElementById('loginModal');

        if (!loginUser || !loginPass) {
            alert('Không tìm thấy form đăng nhập');
            return;
        }

        const username = loginUser.value.trim();
        const password = loginPass.value.trim();

        if (!username || !password) {
            alert('Vui lòng nhập đầy đủ thông tin đăng nhập');
            return;
        }

        try {
            const response = await fetch('/api/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password })
            });

            const result = await response.json();
            
            if (!response.ok) {
                throw new Error(result.error || 'Đăng nhập thất bại');
            }

            // Lưu session mới
            SessionManager.setSession({
                userId: result.userId,
                username: result.username,
                token: result.token
            });

            // Cập nhật UI
            updateLoginUI(result.username);

            // Đóng modal và xóa form
            if (loginModal) {
                loginModal.style.display = 'none';
            }
            loginUser.value = '';
            loginPass.value = '';

            alert('Đăng nhập thành công!');
            window.location.reload();
        } catch (error) {
            console.error('Login error:', error);
            alert(error.message);
        }
    }
};

// Thêm hàm kiểm tra session khi khởi động
async function checkSession() {
    const session = SessionManager.getSession();
    if (session) {
        try {
            // Kiểm tra token với server
            const response = await fetch('/api/verify-session', {
                headers: {
                    'Authorization': `Bearer ${session.token}`
                }
            });

            if (response.ok) {
                // Session hợp lệ, làm mới
                SessionManager.refreshSession();
                updateLoginUI(session.username);
            } else {
                // Session không hợp lệ, xóa
                SessionManager.clearSession();
            }
        } catch (error) {
            console.error('Session verification error:', error);
            SessionManager.clearSession();
        }
    }
}

// Cập nhật hàm initializeApp
async function initializeApp() {
    console.log('Initializing app...');
    
    // Khởi tạo DOM elements
    initializeDOMElements();
    
    // Khởi tạo event listeners
    initializeEventListeners();
    
    // Kiểm tra session
    await checkSession();
    
    // Tải danh sách bài hát
    await fetchSongs();
    
    console.log('App initialized');
}

// Khởi tạo các biến toàn cục
let currentSongIndex = -1;
let songs = [];
let favoriteSongs = [];

// Khởi tạo các phần tử DOM
function initializeDOMElements() {
    // Các nút điều khiển
    window.playPauseBtn = document.getElementById('playPauseBtn');
    window.prevBtn = document.getElementById('prevBtn');
    window.nextBtn = document.getElementById('nextBtn');
    window.volumeSlider = document.getElementById('volumeSlider');
    window.audioPlayer = document.getElementById('audioPlayer');
    window.progress = document.getElementById('progress');
    window.expandBtn = document.getElementById('expandBtn');
    
    // Thông tin bài hát
    window.currentSongThumb = document.getElementById('currentSongThumb');
    window.currentSongTitle = document.getElementById('currentSongTitle');
    window.currentSongArtist = document.getElementById('currentSongArtist');
    window.currentTime = document.getElementById('currentTime');
    window.duration = document.getElementById('duration');
    
    // Các phần tử đăng nhập/đăng ký
    window.loginBtn = document.getElementById('loginBtn');
    window.registerBtn = document.getElementById('registerBtn');
    window.logoutBtn = document.getElementById('logoutBtn');
    window.userNameSpan = document.getElementById('userNameSpan');
    window.userName = document.getElementById('userName');
    
    // Modal
    window.loginModal = document.getElementById('loginModal');
    window.registerModal = document.getElementById('registerModal');
    window.closeLogin = document.getElementById('closeLogin');
    window.closeRegister = document.getElementById('closeRegister');

    // Thêm playlist popup
    addPlaylistPopup();

    // Initialize playlist
    initializePlaylist();
}

// Khởi tạo các sự kiện
function initializeEventListeners() {
    // Sự kiện cho player
    window.playPauseBtn?.addEventListener('click', togglePlay);
    window.prevBtn?.addEventListener('click', playPrevious);
    window.nextBtn?.addEventListener('click', playNext);
    window.volumeSlider?.addEventListener('input', handleVolumeChange);
    window.audioPlayer?.addEventListener('timeupdate', updateProgress);
    window.audioPlayer?.addEventListener('ended', handleSongEnd);
    window.audioPlayer?.addEventListener('loadedmetadata', updateDuration);
    window.progress?.parentElement.addEventListener('click', seek);

    // Sự kiện cho đăng nhập/đăng ký
    window.loginBtn?.addEventListener('click', () => {
        window.loginModal.style.display = 'block';
    });
    window.registerBtn?.addEventListener('click', () => {
        window.registerModal.style.display = 'block';
    });
    window.closeLogin?.addEventListener('click', () => {
        window.loginModal.style.display = 'none';
    });
    window.closeRegister?.addEventListener('click', () => {
        window.registerModal.style.display = 'none';
    });
    window.logoutBtn?.addEventListener('click', handleLogout);

    // Đóng modal khi click ngoài
    window.onclick = (event) => {
        if (event.target === window.loginModal) {
            window.loginModal.style.display = 'none';
        }
        if (event.target === window.registerModal) {
            window.registerModal.style.display = 'none';
        }
    };

    // Sự kiện đăng nhập/đăng ký
    document.getElementById('doLogin')?.addEventListener('click', () => LoginHandler.handleLogin());
    document.getElementById('doRegister')?.addEventListener('click', handleRegister);

    // Thêm sự kiện cho nút mở rộng
    window.expandBtn?.addEventListener('click', () => {
        if (currentSongIndex >= 0 && songs[currentSongIndex]) {
            navigateToPlay(songs[currentSongIndex].id);
        }
    });
}

// Các hàm xử lý player
function togglePlay() {
    if (!window.audioPlayer.src) return;
    
    if (window.audioPlayer.paused) {
        window.audioPlayer.play();
        window.playPauseBtn.innerHTML = '<i class="fas fa-pause"></i>';
    } else {
        window.audioPlayer.pause();
        window.playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';
    }
}

function playPrevious() {
    if (currentSongIndex > 0) {
        playSongAtIndex(currentSongIndex - 1);
    }
}

function playNext() {
    if (currentSongIndex < songs.length - 1) {
        playSongAtIndex(currentSongIndex + 1);
    }
}

function handleVolumeChange() {
    window.audioPlayer.volume = window.volumeSlider.value / 100;
}

// Hàm format thời gian từ giây sang định dạng mm:ss
function formatTime(seconds) {
    if (isNaN(seconds)) return "00:00";
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.floor(seconds % 60);
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
}

// Hàm cập nhật tiến trình phát nhạc
function updateProgress() {
    if (!window.audioPlayer.duration) return;
    
    const percent = (window.audioPlayer.currentTime / window.audioPlayer.duration) * 100;
    window.progress.style.width = percent + '%';
    window.currentTime.textContent = formatTime(window.audioPlayer.currentTime);
    
    // Thêm nút mở rộng bên cạnh thời gian
    if (!document.getElementById('expandBtn') && currentSongIndex >= 0) {
        const timeContainer = window.currentTime.parentElement;
        const expandBtn = document.createElement('button');
        expandBtn.id = 'expandBtn';
        expandBtn.className = 'btn btn-link';
        expandBtn.innerHTML = '<i class="fas fa-expand"></i>';
        expandBtn.style.cssText = 'color: #fff; background: none; border: none; padding: 0 5px; cursor: pointer;';
        expandBtn.title = 'Mở rộng';
        expandBtn.onclick = () => {
            if (currentSongIndex >= 0 && songs[currentSongIndex]) {
                navigateToPlay(songs[currentSongIndex].id);
            }
        };
        timeContainer.appendChild(expandBtn);
    }
}

// Hàm cập nhật thời lượng bài hát
function updateDuration() {
    window.duration.textContent = formatTime(window.audioPlayer.duration);
}

function handleSongEnd() {
    playNext();
}

function seek(event) {
    const progressBar = window.progress.parentElement;
    const percent = (event.offsetX / progressBar.offsetWidth);
    window.audioPlayer.currentTime = percent * window.audioPlayer.duration;
}

// Hàm cập nhật UI khi đăng nhập/đăng xuất
function updateLoginUI(username = null) {
    const loginBtn = document.getElementById('loginBtn');
    const registerBtn = document.getElementById('registerBtn');
    const userNameSpan = document.getElementById('userNameSpan');
    const logoutBtn = document.getElementById('logoutBtn');
    const userName = document.getElementById('userName');

    if (!loginBtn || !registerBtn || !userNameSpan || !logoutBtn || !userName) {
        console.error('Không tìm thấy các phần tử UI cần thiết');
        return;
    }

    if (username || SessionManager.getSession()) {
        // Nếu có username hoặc có session hợp lệ
        loginBtn.style.display = 'none';
        registerBtn.style.display = 'none';
        userNameSpan.style.display = 'inline-block';
        logoutBtn.style.display = 'inline-block';
        userName.textContent = username || SessionManager.getSession().username;
    } else {
        // Nếu chưa đăng nhập
        loginBtn.style.display = 'inline-block';
        registerBtn.style.display = 'inline-block';
        userNameSpan.style.display = 'none';
        logoutBtn.style.display = 'none';
        userName.textContent = '';
    }
}

// Xử lý đăng xuất
async function handleLogout() {
    SessionManager.clearSession();
    updateLoginUI();
    window.location.reload();
}

// Xử lý đăng ký
async function handleRegister() {
    const username = document.getElementById('regUser').value;
    const email = document.getElementById('regEmail').value;
    const password = document.getElementById('regPass').value;

    try {
        const response = await fetch('/api/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, email, password })
        });

        const result = await response.json();
        
        if (!response.ok) {
            throw new Error(result.error || 'Đăng ký thất bại');
        }

        alert('Đăng ký thành công! Vui lòng đăng nhập.');
        window.registerModal.style.display = 'none';
        window.loginModal.style.display = 'block';
    } catch (error) {
        console.error('Register error:', error);
        alert(error.message);
    }
}

// Hàm lấy danh sách bài hát
async function fetchSongs() {
    try {
        const response = await fetch('/api/songs');
        if (!response.ok) {
            throw new Error('Không thể lấy danh sách bài hát');
        }
        
        songs = await response.json();
        console.log('Danh sách bài hát:', songs);
        
        // Hiển thị bài hát
        displayFeaturedSongs(songs);
        renderSongs(songs);
    } catch (error) {
        console.error('Lỗi khi lấy danh sách bài hát:', error);
    }
}

// Hàm hiển thị bài hát nổi bật
function displayFeaturedSongs(songs) {
    const featuredSongsContainer = document.getElementById('featuredSongs');
    if (!featuredSongsContainer) return;

    // Lấy 6 bài hát mới nhất
    const featuredSongs = songs.slice(0, 6);
    
    featuredSongsContainer.innerHTML = featuredSongs.map((song, index) => `
        <div class="col-md-4 mb-4">
            <div class="card h-100" onclick="playSongAtIndex(${index})" style="cursor: pointer;">
                <img src="${song.image_url || 'images/default-song.jpg'}" class="card-img-top" alt="${song.title}">
                <div class="card-body">
                    <h5 class="card-title">${song.title}</h5>
                    <p class="card-text">${song.artist_name || 'Không có nghệ sĩ'}</p>
                    <button class="btn btn-outline-primary" onclick="event.stopPropagation(); addToFavorites(${song.id})">
                        <i class="fas fa-heart"></i>
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

// Hàm chuyển hướng sang trang phát nhạc
function navigateToPlay(songId, event) {
    if (event) {
        event.preventDefault();
        event.stopPropagation();
    }
    
    // Lưu thông tin người dùng và thời gian phát vào localStorage
    const session = SessionManager.getSession();
    if (session) {
        localStorage.setItem('userId', session.userId);
        localStorage.setItem('userName', session.username);
    }
    
    // Lưu thời gian phát hiện tại
    if (window.audioPlayer) {
        localStorage.setItem('currentTime', window.audioPlayer.currentTime.toString());
        localStorage.setItem('lastPlayedSong', songId.toString());
        console.log('Đã lưu thời gian:', window.audioPlayer.currentTime);
    }
    
    window.location.href = `/userplay.html?id=${songId}`;
}

// Hàm phát bài hát theo index
function playSongAtIndex(index) {
    if (index < 0 || index >= songs.length) return;
    currentSongIndex = index;
    const song = songs[index];
    
    // Cập nhật audio player
    window.audioPlayer.src = song.file_url;
    window.audioPlayer.play();
    window.playPauseBtn.innerHTML = '<i class="fas fa-pause"></i>';
    
    // Cập nhật thông tin bài hát
    if (window.currentSongThumb) window.currentSongThumb.src = song.image_url || 'images/default-song.jpg';
    if (window.currentSongTitle) window.currentSongTitle.textContent = song.title;
    if (window.currentSongArtist) window.currentSongArtist.textContent = song.artist_name || 'Không có nghệ sĩ';
}

// Hàm hiển thị danh sách bài hát
function renderSongs(songs) {
    const songListContainer = document.getElementById('songList');
    if (!songListContainer) return;

    songListContainer.innerHTML = songs.map((song, index) => `
        <div class="col-md-4 mb-4">
            <div class="card h-100" onclick="playSongAtIndex(${index})" style="cursor: pointer;">
                <img src="${song.image_url || 'images/default-song.jpg'}" class="card-img-top" alt="${song.title}">
                <div class="card-body">
                    <h5 class="card-title">${song.title}</h5>
                    <p class="card-text">${song.artist_name || 'Không có nghệ sĩ'}</p>
                    <button class="btn btn-outline-primary" onclick="event.stopPropagation(); addToFavorites(${song.id})">
                        <i class="fas fa-heart"></i>
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

// Hàm thêm vào yêu thích
async function addToFavorites(songId) {
    const session = SessionManager.getSession();
    if (!session) {
        alert('Vui lòng đăng nhập để thêm vào yêu thích');
        return;
    }

    try {
        const response = await fetch('/api/favorites', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${session.token}`
            },
            body: JSON.stringify({
                userId: session.userId,
                songId: songId
            })
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error);
        }

        alert('Đã thêm vào danh sách yêu thích!');
    } catch (error) {
        console.error('Lỗi khi thêm vào yêu thích:', error);
        alert(error.message);
    }
}

// Khởi động ứng dụng khi trang được tải
document.addEventListener('DOMContentLoaded', async () => {
    initializeDOMElements();
    initializeEventListeners();
    
    // Kiểm tra session và cập nhật UI
    const session = SessionManager.getSession();
    if (session) {
        updateLoginUI(session.username);
    }
    
    await fetchSongs();
});

// Thêm HTML cho playlist popup
function addPlaylistPopup() {
    // Kiểm tra nếu playlist popup đã tồn tại
    if (document.querySelector('.playlist-popup')) return;

    // Thêm HTML cho playlist popup
    const playlistPopup = document.createElement('div');
    playlistPopup.className = 'playlist-popup';
    playlistPopup.innerHTML = `
        <div class="playlist-header">
            <div class="playlist-title">Danh sách phát</div>
            <button class="close-playlist">&times;</button>
        </div>
        <div class="playlist-content"></div>
    `;
    document.body.appendChild(playlistPopup);

    // Thêm nút playlist vào player
    const playerControls = document.querySelector('.volume-control');
    
}

// Xử lý playlist sidebar
function initializePlaylist() {
    const btnPlaylist = document.querySelector('.btn-playlist');
    const playlistSidebar = document.querySelector('.playlist-sidebar');
    const btnShuffle = document.querySelector('.btn-shuffle');
    const autoplayToggle = document.getElementById('autoplay');

    // Toggle playlist
    btnPlaylist?.addEventListener('click', () => {
        playlistSidebar.classList.toggle('active');
        fetchFavoriteSongs();
    });

    // Click outside to close
    document.addEventListener('click', (e) => {
        if (playlistSidebar?.classList.contains('active') &&
            !playlistSidebar.contains(e.target) &&
            !e.target.closest('.btn-playlist')) {
            playlistSidebar.classList.remove('active');
        }
    });

    // Shuffle playlist
    btnShuffle?.addEventListener('click', () => {
        if (!songs.length) return;
        
        // Lưu lại bài hát hiện tại
        const currentSong = songs[currentSongIndex];
        
        // Trộn danh sách
        for (let i = songs.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [songs[i], songs[j]] = [songs[j], songs[i]];
        }
        
        // Cập nhật index của bài hát hiện tại
        currentSongIndex = songs.findIndex(song => song.id === currentSong.id);
        
        // Cập nhật playlist
        updatePlaylistContent();
    });

    // Autoplay toggle
    autoplayToggle?.addEventListener('change', () => {
        if (autoplayToggle.checked) {
            window.audioPlayer.addEventListener('ended', playNext);
        } else {
            window.audioPlayer.removeEventListener('ended', playNext);
        }
    });
}

// Cập nhật nội dung playlist
function updatePlaylistContent() {
    const playlistContent = document.querySelector('.playlist-content');
    if (!playlistContent) return;

    if (!favoriteSongs.length) {
        playlistContent.innerHTML = '<div class="text-center text-muted py-4">Chưa có bài hát yêu thích nào</div>';
        return;
    }

    playlistContent.innerHTML = favoriteSongs.map((song, index) => `
        <div class="playlist-item"
             onclick="playSongById(${song.id})">
            <img src="${song.image_url || 'images/default-song.jpg'}" alt="${song.title}">
            <div class="playlist-item-info">
                <div class="playlist-item-title">${song.title}</div>
                <div class="playlist-item-artist">${song.artist_name || 'Không có nghệ sĩ'}</div>
            </div>
        </div>
    `).join('');
}

// Hàm phát bài hát theo id
window.playSongById = function(songId) {
    const song = favoriteSongs.find(s => s.id === songId);
    if (song) {
        // Set lại audio player
        window.audioPlayer.src = song.file_url;
        window.audioPlayer.play();
        window.playPauseBtn.innerHTML = '<i class="fas fa-pause"></i>';
        // Cập nhật thông tin bài hát
        if (window.currentSongThumb) window.currentSongThumb.src = song.image_url || 'images/default-song.jpg';
        if (window.currentSongTitle) window.currentSongTitle.textContent = song.title;
        if (window.currentSongArtist) window.currentSongArtist.textContent = song.artist_name || 'Không có nghệ sĩ';
        updatePlaylistContent();
    }
};

async function fetchFavoriteSongs() {
    try {
        const session = SessionManager.getSession();
        const res = await fetch('/api/favorites', {
            headers: {
                'Authorization': session ? `Bearer ${session.token}` : ''
            }
        });
        if (!res.ok) throw new Error('Không thể lấy danh sách yêu thích');
        favoriteSongs = await res.json();
        updatePlaylistContent();
    } catch (e) {
        favoriteSongs = [];
        updatePlaylistContent();
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('searchInput');
    const searchBtn = document.getElementById('searchBtn');
    // Giả sử bạn có biến songs chứa danh sách bài hát đã load từ API

    function renderSongList(filteredSongs) {
        renderSongs(filteredSongs);
    }

    function handleSearch() {
        const keyword = searchInput.value.trim().toLowerCase();
        if (!keyword) {
            renderSongList(songs); // Hiển thị lại toàn bộ nếu không nhập gì
            return;
        }
        const filtered = songs.filter(song =>
            song.title.toLowerCase().includes(keyword) ||
            (song.artist_name && song.artist_name.toLowerCase().includes(keyword))
        );
        renderSongList(filtered);
    }

    if (searchBtn) {
        searchBtn.addEventListener('click', handleSearch);
    }
    if (searchInput) {
        searchInput.addEventListener('keyup', (e) => {
            if (e.key === 'Enter') handleSearch();
        });
    }
});