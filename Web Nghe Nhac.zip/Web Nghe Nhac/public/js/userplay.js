// Quản lý session
const SessionManager = {
    // Thời gian token hết hạn (24 giờ)
    TOKEN_EXPIRY: 24 * 60 * 60 * 1000,

    // Lưu thông tin đăng nhập
    setSession(userData) {
        const session = {
            userId: userData.userId,
            username: userData.username,
            token: userData.token,
            expiresAt: Date.now() + this.TOKEN_EXPIRY
        };
        
        // Lưu vào sessionStorage
        sessionStorage.setItem('userSession', JSON.stringify(session));
    },

    // Kiểm tra session hiện tại
    getSession() {
        const sessionData = sessionStorage.getItem('userSession');
        if (!sessionData) return null;

        const session = JSON.parse(sessionData);
        
        // Kiểm tra hết hạn
        if (Date.now() > session.expiresAt) {
            this.clearSession();
            return null;
        }

        return session;
    },

    // Xóa session khi đăng xuất
    clearSession() {
        sessionStorage.removeItem('userSession');
        localStorage.removeItem('userId');
        localStorage.removeItem('userName');
    },

    // Làm mới session
    refreshSession() {
        const session = this.getSession();
        if (session) {
            session.expiresAt = Date.now() + this.TOKEN_EXPIRY;
            sessionStorage.setItem('userSession', JSON.stringify(session));
        }
    }
};

// Constants
const API_BASE_URL = 'http://localhost:3001';
const DEFAULT_IMAGE = '/images/default-song.jpg';

// Utility functions
const formatTime = (time) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
};

document.addEventListener('DOMContentLoaded', async () => {
    // Thêm kiểm tra session ngay đầu file
    console.log('=== Kiểm tra Session ===');
    console.log('localStorage:', {
        userId: localStorage.getItem('userId'),
        userName: localStorage.getItem('userName'),
        allKeys: Object.keys(localStorage),
        fullStorage: { ...localStorage }
    });

    // Lấy ID bài hát từ URL
    const urlParams = new URLSearchParams(window.location.search);
    const songId = urlParams.get('id');
    console.log('Song ID from URL:', songId);

    // Hàm kiểm tra session
    function checkSession() {
        const session = SessionManager.getSession();
        if (!session) {
            // Lưu URL hiện tại và chuyển hướng
            localStorage.setItem('returnUrl', window.location.href);
            console.log('Đã lưu returnUrl:', window.location.href);
            window.location.href = '/user.html';
            return false;
        }
        return true;
    }

    // Gọi hàm kiểm tra session khi khởi tạo
    if (!checkSession()) {
        console.log('Chuyển hướng về trang đăng nhập do chưa có session');
        return;
    }

    // Lấy tham chiếu đến các phần tử
    const songList = document.getElementById('databaseSongList');
    const databaseSongList = document.getElementById('databaseSongList');
    const favoritesList = document.getElementById('favoritesList');
    const audioPlayer = document.getElementById('audioPlayer');
    const playPauseBtn = document.getElementById('playPauseBtn');
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    const shuffleBtn = document.getElementById('shuffleBtn');
    const repeatBtn = document.getElementById('repeatBtn');
    const progress = document.getElementById('progress');
    const progressBar = document.querySelector('.progress-bar');
    const currentTimeSpan = document.getElementById('currentTime');
    const durationSpan = document.getElementById('duration');
    const volumeBtn = document.getElementById('volumeBtn');
    const volumeSlider = document.getElementById('volumeSlider');
    const volumeContainer = document.querySelector('.volume-slider');
    const currentSongThumb = document.getElementById('currentSongThumb');
    const currentSongTitle = document.getElementById('currentSongTitle');
    const currentSongArtist = document.getElementById('currentSongArtist');
    const shuffleAllBtn = document.getElementById('shuffleAllBtn');
    const shuffleFavBtn = document.getElementById('shuffleFavBtn');
    const commentToggleBtn = document.getElementById('commentToggleBtn');
    const closeCommentsBtn = document.getElementById('closeComments');
    const commentSection = document.querySelector('.comment-section');
    const commentList = document.getElementById('commentList');
    const commentInput = document.getElementById('commentInput');
    const submitComment = document.getElementById('submitComment');
    const sortBtn = document.getElementById('sortBtn');
    const filterBtn = document.getElementById('filterBtn');
    const toggleLyricsBtn = document.getElementById('toggleLyrics');
    const songCover = document.getElementById('songCover');
    const songTitle = document.getElementById('songTitle');
    const songArtist = document.getElementById('songArtist');
    
    // Sidebar bình luận
    const commentSidebar = document.getElementById('commentSidebar');
    const openSidebarBtn = document.getElementById('openSidebarBtn');
    const closeSidebarBtn = document.getElementById('closeSidebarBtn');
    const sidebarCommentList = document.getElementById('sidebarCommentList');
    const sidebarCommentInput = document.getElementById('sidebarCommentInput');
    const sidebarSubmitComment = document.getElementById('sidebarSubmitComment');
    
    // Biến trạng thái
    let songs = [];
    let currentSongIndex = 0;
    let isPlaying = false;
    let isShuffled = false;
    let isRepeating = false;
    let favoriteSongs = [];
    let sortOrder = 'default';
    
    // Các biến toàn cục
    let currentAudio = null;
    let isAutoScrollEnabled = true;
    let currentLyrics = [];
    let lyricTimestamps = [];
    let currentLyricIndex = -1;
    
    // Thêm script Essentia.js
    const essentiaScript = document.createElement('script');
    essentiaScript.src = 'https://cdn.jsdelivr.net/npm/essentia.js@0.1.3/dist/essentia.js';
    document.head.appendChild(essentiaScript);

    let essentia;
    let beatDetector;
    
    essentiaScript.onload = async () => {
        essentia = new Essentia(EssentiaWASM);
        beatDetector = new essentia.BeatTrackerDegara();
        console.log('Đã khởi tạo Essentia.js');
    };

    // Hàm lấy danh sách bài hát từ API
    async function fetchSongs() {
        console.log('Đang lấy danh sách bài hát...');
        try {
            const response = await fetch('http://localhost:3000/api/songs');
            if (!response.ok) {
                throw new Error(`Không thể lấy danh sách bài hát: ${response.status} ${response.statusText}`);
            }
            const data = await response.json();
            console.log('Đã lấy được', data.length, 'bài hát');
            songs = data;
            renderSongList(songs);

            // Nếu có songId từ URL, phát bài hát đó
            if (songId) {
                const songIndex = songs.findIndex(song => song.id.toString() === songId);
                if (songIndex !== -1) {
                    currentSongIndex = songIndex;
                    playSong(songIndex);
                }
            } else if (songs.length > 0) {
                // Nếu không có songId, chỉ cập nhật thông tin bài hát đầu tiên
                currentSongIndex = 0;
                updateCurrentSongInfo(songs[0]);
            }
        } catch (error) {
            console.error('Lỗi khi lấy danh sách bài hát:', error);
        }
    }

    // Hàm cập nhật thông tin bài hát đang phát
    function updateCurrentSongInfo(song) {
        if (!song) return;
        
        // Cập nhật tiêu đề và nghệ sĩ
        currentSongTitle.textContent = song.title;
        currentSongArtist.textContent = song.artist_name || 'Không xác định';
        if (songTitle) songTitle.textContent = song.title;
        if (songArtist) songArtist.textContent = song.artist_name || 'Không xác định';
        
        // Cập nhật ảnh album và ảnh player
        if (songCover) {
            songCover.src = song.image_url || '/images/default-song.jpg';
            songCover.alt = song.title;
        }
        currentSongThumb.src = song.image_url || '/images/default-song.jpg';
        currentSongThumb.alt = song.title;

        // Cập nhật nút play/pause
        playPauseBtn.innerHTML = '<i class="fas fa-pause"></i>';
    }

    // Hàm cập nhật trạng thái active cho bài hát đang phát
    function updateActiveSong() {
        // Xóa class active từ tất cả các bài hát
        document.querySelectorAll('.song-item').forEach(item => {
            item.classList.remove('active');
        });
        
        // Thêm class active cho bài hát đang phát
        const currentSongItem = document.querySelector(`.song-item[data-index="${currentSongIndex}"]`);
        if (currentSongItem) {
            currentSongItem.classList.add('active');
            // Cuộn đến bài hát đang phát
            currentSongItem.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
    }

    // Hàm phát bài hát
    async function playSong(index) {
        if (index < 0 || index >= songs.length) return;
        
        currentSongIndex = index;
        const song = songs[currentSongIndex];
        console.log('Đang phát bài hát:', song);
        
        try {
            // Phát nhạc
            audioPlayer.src = song.file_url;
            await audioPlayer.play();
            
            // Cập nhật thông tin và lyrics
            updateCurrentSongInfo(song);
            updateActiveSong();
            updateLyrics(song);
            
        } catch (error) {
            console.error('Lỗi khi phát nhạc:', error);
        }
    }

    // Hàm parse thời gian từ format LRC [mm:ss.xx]
    function parseLRCTime(timeStr) {
        const match = timeStr.match(/\[(\d{2}):(\d{2})\.(\d{2})\]/);
        if (!match) return null;
        
        const minutes = parseInt(match[1]);
        const seconds = parseInt(match[2]);
        const hundredths = parseInt(match[3]);
        
        return minutes * 60 + seconds + hundredths / 100;
    }

    // Hàm parse lyrics format LRC
    function parseLRC(lrcContent) {
        if (!lrcContent) return [];
        
        const lines = lrcContent.split('\n');
        const result = [];
        
        lines.forEach(line => {
            // Tìm timestamp trong dòng
            const timeMatch = line.match(/^\[(\d{2}:\d{2}\.\d{2})\]/);
            if (timeMatch) {
                const time = parseLRCTime(timeMatch[0]);
                const text = line.replace(/^\[\d{2}:\d{2}\.\d{2}\]/, '').trim();
                if (text) {
                    result.push({ time, text });
                }
            }
        });
        
        // Sắp xếp theo thời gian
        return result.sort((a, b) => a.time - b.time);
    }

    // Hàm chuyển đổi thời gian thành format LRC
    function formatLRCTime(seconds) {
        const minutes = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        const hundredths = Math.floor((seconds % 1) * 100);
        return `[${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}.${String(hundredths).padStart(2, '0')}]`;
    }

    // Hàm cập nhật lyrics
    function updateLyrics(song) {
        const lyricsContent = document.querySelector('.lyrics-content');
        
        if (!lyricsContent || !song.lyrics) {
            console.log('Không tìm thấy lyrics hoặc phần tử lyrics-content');
            return;
        }

        // Xử lý lyrics và hiển thị đơn giản
        const lines = processLyrics(song.lyrics);
        if (lines.length === 0) {
            lyricsContent.innerHTML = '<p class="no-lyrics">Không có lời bài hát</p>';
            return;
        }

        // Tạo HTML cho lyrics - chỉ hiển thị text đơn giản
        const lyricsHTML = lines
            .map((line, index) => `
                <div class="lyrics-line" data-line="${index}">
                    ${line}
                </div>
            `)
            .join('');
        
        lyricsContent.innerHTML = lyricsHTML;
    }

    function processLyrics(lyrics) {
        if (!lyrics) return [];
        
        // Tách lyrics thành mảng và lọc
        const lines = lyrics
            .split('\n')
            .map(line => line.trim())
            .filter(line => line && line !== '\n' && line !== '');
            
        // Loại bỏ các dòng trùng lặp liền kề
        const uniqueLines = lines.filter((line, index, arr) => {
            return line !== arr[index - 1];
        });
        
        return uniqueLines;
    }

    // Hàm render danh sách bài hát
    function renderSongList(songs) {
        console.log('Đang hiển thị danh sách bài hát:', songs.length);
        if (!songList || !songs || songs.length === 0) {
            console.error('Không có bài hát hoặc không tìm thấy phần tử songList');
            return;
        }

        songList.innerHTML = songs.map((song, index) => `
            <li class="song-item" data-index="${index}">
                <div class="song-item-left">
                    <div class="song-info">
                        <span class="title">
                            <img src="${song.image_url || '/images/default-song.jpg'}" alt="${song.title}" width="50" height="50" style="object-fit: cover; border-radius: 5px;">
                            ${song.title}
                        </span>
                        <span class="artist"><i class="fas fa-user-alt"></i> ${song.artist_name || 'Không xác định'} </span>
                    </div>
                </div>
            </li>
        `).join('');

        console.log('Đã render xong danh sách bài hát');

        // Thêm sự kiện click cho mỗi bài hát
        document.querySelectorAll('.song-item').forEach(item => {
            item.addEventListener('click', () => {
                const index = parseInt(item.dataset.index);
                playSong(index);
            });
        });
    }

    // Xử lý sự kiện play/pause
    playPauseBtn.addEventListener('click', () => {
            if (audioPlayer.paused) {
                audioPlayer.play();
            playPauseBtn.innerHTML = '<i class="fas fa-pause"></i>';
            } else {
                audioPlayer.pause();
            playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';
        }
    });

    // Xử lý next/prev
    nextBtn.addEventListener('click', () => {
        playSong((currentSongIndex + 1) % songs.length);
    });

    prevBtn.addEventListener('click', () => {
        playSong((currentSongIndex - 1 + songs.length) % songs.length);
    });

    // Cập nhật xử lý timeupdate - loại bỏ phần highlight lyrics
    audioPlayer.addEventListener('timeupdate', () => {
        if (audioPlayer.duration) {
        const percent = (audioPlayer.currentTime / audioPlayer.duration) * 100;
            progress.style.width = percent + '%';
        currentTimeSpan.textContent = formatTime(audioPlayer.currentTime);
        }
    });

    audioPlayer.addEventListener('loadedmetadata', () => {
        durationSpan.textContent = formatTime(audioPlayer.duration);
    });

    progressBar.addEventListener('click', (e) => {
        const percent = e.offsetX / progressBar.offsetWidth;
        audioPlayer.currentTime = percent * audioPlayer.duration;
    });

    // Xử lý âm lượng
    // Hiển thị/ẩn thanh âm lượng khi click vào nút volume
    volumeBtn.addEventListener('click', () => {
        volumeContainer.classList.toggle('show');
    });

    // Cập nhật âm lượng khi kéo thanh trượt
    volumeSlider.addEventListener('input', (e) => {
        const volume = e.target.value / 100;
        audioPlayer.volume = volume;
        
        // Cập nhật icon dựa trên mức âm lượng
        if (volume === 0) {
            volumeBtn.innerHTML = '<i class="fas fa-volume-mute"></i>';
        } else if (volume < 0.5) {
            volumeBtn.innerHTML = '<i class="fas fa-volume-down"></i>';
        } else {
            volumeBtn.innerHTML = '<i class="fas fa-volume-up"></i>';
        }
    });

    // Ẩn thanh âm lượng khi click ra ngoài
    document.addEventListener('click', (e) => {
        if (volumeBtn && volumeContainer && !volumeBtn.contains(e.target) && !volumeContainer.contains(e.target)) {
            volumeContainer.classList.remove('show');
        }
    });

    // Lưu và khôi phục âm lượng
    const savedVolume = localStorage.getItem('volume');
    if (savedVolume !== null) {
        volumeSlider.value = savedVolume;
        audioPlayer.volume = savedVolume / 100;
    }

    volumeSlider.addEventListener('change', () => {
        localStorage.setItem('volume', volumeSlider.value);
    });

    // Xử lý toggle lyrics
    if (toggleLyricsBtn) {
        toggleLyricsBtn.addEventListener('click', () => {
            const lyricsContent = document.querySelector('.lyrics-content');
            if (lyricsContent) {
                const isVisible = lyricsContent.style.display !== 'none';
                lyricsContent.style.display = isVisible ? 'none' : 'block';
                toggleLyricsBtn.innerHTML = isVisible ? 
                    '<i class="fas fa-chevron-down"></i>' : 
                    '<i class="fas fa-chevron-up"></i>';
            }
        });
    }

    // Thêm event listener cho storage changes
    window.addEventListener('storage', (e) => {
        console.log('Storage changed:', {
            key: e.key,
            oldValue: e.oldValue,
            newValue: e.newValue
        });
        
        if (e.key === 'userId' || e.key === 'userName') {
            // Kiểm tra session khi có thay đổi
            if (!checkSession()) {
                console.log('Session đã thay đổi và không còn hợp lệ');
                return;
            }
        }
    });

    // Mở sidebar
    if (openSidebarBtn && commentSidebar) {
        openSidebarBtn.addEventListener('click', () => {
            commentSidebar.classList.add('open');
            loadSidebarComments();
        });
    }
    // Đóng sidebar
    if (closeSidebarBtn && commentSidebar) {
        closeSidebarBtn.addEventListener('click', () => {
            commentSidebar.classList.remove('open');
        });
    }
    // Gửi bình luận từ sidebar (lưu vào MySQL)
    if (sidebarSubmitComment && sidebarCommentInput) {
        sidebarSubmitComment.addEventListener('click', async () => {
            const content = sidebarCommentInput.value.trim();
            if (!content) {
                alert('Vui lòng nhập nội dung bình luận');
                return;
            }
        const currentSong = songs[currentSongIndex];
        if (!currentSong) return;

            // Kiểm tra đăng nhập
        const session = SessionManager.getSession();
        if (!session) {
                alert('Bạn cần đăng nhập để bình luận!');
            window.location.href = '/user.html';
            return;
        }
            const userId = session.userId;

            try {
                // Log giá trị trước khi gửi bình luận
                console.log('Gửi bình luận:', {
                    song_id: currentSong.id,
                    user_id: userId,
                    comment: content
                });
                const response = await fetch('/api/comments', {
                method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        song_id: currentSong.id,
                        user_id: userId,
                        comment: content
                    })
                });
            const data = await response.json();
                if (!response.ok) throw new Error(data.error || 'Lỗi gửi bình luận');
                sidebarCommentInput.value = '';
                loadSidebarComments();
            } catch (err) {
                alert('Không gửi được bình luận: ' + err.message);
            }
        });
    }
    // Hàm load bình luận cho sidebar (lấy từ MySQL)
    async function loadSidebarComments() {
        if (!sidebarCommentList) return;
        const currentSong = songs[currentSongIndex];
        if (!currentSong) return;
        console.log('Gọi API lấy bình luận cho bài hát:', currentSong.id);
        try {
            const response = await fetch(`/api/comments/${currentSong.id}`);
            if (!response.ok) {
                sidebarCommentList.innerHTML = '<li class="no-comments">Chưa có bình luận nào cho bài hát này</li>';
                return;
            }
            const comments = await response.json();
            console.log('Kết quả API:', comments);
            if (!Array.isArray(comments) || comments.length === 0) {
                sidebarCommentList.innerHTML = '<li class="no-comments">Chưa có bình luận nào cho bài hát này</li>';
                return;
            }
            sidebarCommentList.innerHTML = comments.map(comment => `
                <li class="comment-item">
                    <div class="comment-header">
                        <span class="comment-user"><i class="fas fa-user"></i> ${comment.username ? comment.username : (comment.user_id ? 'User #' + comment.user_id : 'Người dùng ẩn danh')}</span>
                        <span class="comment-time">${formatCommentTime(new Date(comment.created_at))}</span>
                    </div>
                    <div class="comment-content">${comment.comment}</div>
                </li>
            `).join('');
        } catch (err) {
            sidebarCommentList.innerHTML = '<li class="comment-error">Không thể tải bình luận</li>';
        }
    }
    // Tự động load lại bình luận khi đổi bài hát nếu sidebar đang mở
    if (audioPlayer) {
        audioPlayer.addEventListener('play', () => {
            if (commentSidebar && commentSidebar.classList.contains('open')) {
                loadSidebarComments();
            }
        });
    }

    // Xử lý nút phát ngẫu nhiên (shuffleAllBtn)
    if (shuffleAllBtn) {
        shuffleAllBtn.addEventListener('click', () => {
            if (songs.length > 0) {
                const randomIndex = Math.floor(Math.random() * songs.length);
                playSong(randomIndex);
            }
        });
    }

    // Xử lý nút sắp xếp (sortBtn)
    let sortAsc = true;
    if (sortBtn) {
        sortBtn.addEventListener('click', () => {
            if (songs.length > 0) {
                songs.sort((a, b) => {
                    if (sortAsc) {
                        return a.title.localeCompare(b.title);
                    } else {
                        return b.title.localeCompare(a.title);
                    }
                });
                sortAsc = !sortAsc;
                renderSongList(songs);
            }
        });
    }

    // Xử lý nút lọc (filterBtn)
    if (filterBtn) {
        filterBtn.addEventListener('click', () => {
            if (songs.length > 0) {
                const artistName = songs[0].artist_name;
                const filtered = songs.filter(song => song.artist_name === artistName);
                renderSongList(filtered);
            }
        });
    }

    // Khởi tạo ban đầu
    await fetchSongs();
    
    // Thêm event listener cho các tab
    const tabs = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.song-list-container');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            // Ẩn tất cả tab content
            tabContents.forEach(content => {
                content.style.display = 'none';
            });
            
            // Bỏ active class từ tất cả tab
            tabs.forEach(t => t.classList.remove('active'));
            
            // Thêm active class cho tab được click
            tab.classList.add('active');
            
            // Hiển thị content tương ứng
            const targetId = tab.getAttribute('data-tab');
            document.getElementById(targetId).style.display = 'block';
            
           
        });
    });
});

// Đảm bảo có hàm formatCommentTime
function formatCommentTime(date) {
    if (!date) return '';
    if (typeof date === 'string') date = new Date(date);
    return date.toLocaleString('vi-VN');
}