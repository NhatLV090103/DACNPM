// Định nghĩa AdminFunctions
const AdminFunctions = {
    // Hàm lấy danh sách bài hát
    async fetchSongs() {
        try {
            console.log('Đang gọi API lấy danh sách bài hát...');
            const response = await fetch('/api/songs');
            
            console.log('Response status:', response.status);
            console.log('Response headers:', response.headers);
            
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(`HTTP error! status: ${response.status}, message: ${errorData.error || 'Unknown error'}`);
            }
            
            const songs = await response.json();
            console.log('Dữ liệu nhận được:', songs);
            
            this.displaySongs(songs);
        } catch (error) {
            console.error('Chi tiết lỗi khi lấy danh sách bài hát:', error);
            const songTableBody = document.getElementById('songTableBody');
            if (songTableBody) {
                songTableBody.innerHTML = `
                    <tr>
                        <td colspan="6">
                            <div class="error-message">
                                <i class="fas fa-exclamation-circle"></i>
                                Có lỗi xảy ra khi tải danh sách bài hát: ${error.message}
                                <button onclick="AdminFunctions.fetchSongs()" class="btn btn-sm btn-primary mt-2">
                                    <i class="fas fa-sync"></i> Thử lại
                                </button>
                            </div>
                        </td>
                    </tr>
                `;
            }
        }
    },

    // Hàm hiển thị danh sách bài hát
    displaySongs(songs) {
        const songTableBody = document.getElementById('songTableBody');
        if (!songTableBody) return;

        if (!Array.isArray(songs)) {
            console.error('Dữ liệu không phải là mảng:', songs);
            songTableBody.innerHTML = `
                <tr>
                    <td colspan="6">
                        <div class="error-message">
                            <i class="fas fa-exclamation-circle"></i>
                            Có lỗi với định dạng dữ liệu
                        </div>
                    </td>
                </tr>
            `;
            return;
        }

        if (songs.length === 0) {
            songTableBody.innerHTML = `
                <tr>
                    <td colspan="6" class="text-center py-4">
                        <div class="empty-message">
                            <i class="fas fa-music fa-2x mb-3"></i>
                            <p>Chưa có bài hát nào</p>
                        </div>
                    </td>
                </tr>
            `;
            return;
        }

        songTableBody.innerHTML = songs.map(song => `
            <tr>
                <td>
                    ${song.image_url ? 
                        `<img src="${song.image_url}" alt="${song.title}" style="width: 50px; height: 50px; object-fit: cover;">` : 
                        '<div class="no-image">No Image</div>'
                    }
                </td>
                <td>${song.title}</td>
                <td>${song.artist_name || 'Chưa có'}</td>
                <td>${song.album_name || 'Chưa có'}</td>
                <td>${song.genre_name || 'Chưa có'}</td>
                <td>
                    <div class="btn-group">
                        <button class="btn btn-sm btn-primary" onclick="AdminFunctions.editSong(${song.id})">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="AdminFunctions.deleteSong(${song.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    },

    // Hàm xóa bài hát
    async deleteSong(id) {
        if (!confirm('Bạn có chắc muốn xóa bài hát này?')) return;

        try {
            const response = await fetch(`/api/songs/${id}`, {
                method: 'DELETE'
            });

            if (!response.ok) {
                throw new Error('Không thể xóa bài hát');
            }

            await this.fetchSongs();
            alert('Đã xóa bài hát thành công');
        } catch (error) {
            console.error('Lỗi khi xóa bài hát:', error);
            alert('Không thể xóa bài hát');
        }
    },

    // Hàm sửa bài hát
    async editSong(id) {
        try {
            const response = await fetch(`/api/songs/${id}`);
            const song = await response.json();
            
            // Tạo form chỉnh sửa
            const form = document.createElement('form');
            form.innerHTML = `
                <div class="mb-3">
                    <label class="form-label">Tiêu đề</label>
                    <input type="text" class="form-control" name="title" value="${song.title}" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Nghệ sĩ</label>
                    <select class="form-control" name="artist_id" required>
                        <option value="">Chọn nghệ sĩ</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Album</label>
                    <select class="form-control" name="album_id">
                        <option value="">Chọn album</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Thể loại</label>
                    <select class="form-control" name="genre_id">
                        <option value="">Chọn thể loại</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Thông tin</label>
                    <textarea class="form-control" name="info">${song.info || ''}</textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label">Lời bài hát</label>
                    <textarea class="form-control" name="lyrics">${song.lyrics || ''}</textarea>
                </div>
            `;

            // Tạo modal
            const modal = document.createElement('div');
            modal.className = 'modal fade';
            modal.innerHTML = `
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Chỉnh sửa bài hát</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            ${form.innerHTML}
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                            <button type="button" class="btn btn-primary" id="saveChanges">Lưu thay đổi</button>
                        </div>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);

            // Khởi tạo modal
            const modalInstance = new bootstrap.Modal(modal);
            modalInstance.show();

            // Load dữ liệu cho các select box
            const artistSelect = modal.querySelector('select[name="artist_id"]');
            const albumSelect = modal.querySelector('select[name="album_id"]');
            const genreSelect = modal.querySelector('select[name="genre_id"]');

            // Load danh sách nghệ sĩ
            const artists = await fetch('/api/artists').then(res => res.json());
            artistSelect.innerHTML = `
                <option value="">Chọn nghệ sĩ</option>
                ${artists.map(artist => `
                    <option value="${artist.id}" ${artist.id === song.artist_id ? 'selected' : ''}>
                        ${artist.name}
                    </option>
                `).join('')}
            `;

            // Load danh sách album
            const albums = await fetch('/api/albums').then(res => res.json());
            albumSelect.innerHTML = `
                <option value="">Chọn album</option>
                ${albums.map(album => `
                    <option value="${album.id}" ${album.id === song.album_id ? 'selected' : ''}>
                        ${album.name}
                    </option>
                `).join('')}
            `;

            // Load danh sách thể loại
            const genres = await fetch('/api/genres').then(res => res.json());
            genreSelect.innerHTML = `
                <option value="">Chọn thể loại</option>
                ${genres.map(genre => `
                    <option value="${genre.id}" ${genre.id === song.genre_id ? 'selected' : ''}>
                        ${genre.name}
                    </option>
                `).join('')}
            `;

            // Xử lý sự kiện lưu
            const saveButton = modal.querySelector('#saveChanges');
            saveButton.addEventListener('click', async () => {
                const formData = new FormData(form);
                const updateData = {
                    title: formData.get('title'),
                    artist_id: formData.get('artist_id') || null,
                    album_id: formData.get('album_id') || null,
                    genre_id: formData.get('genre_id') || null,
                    file_url: song.file_url,
                    image_url: song.image_url,
                    info: formData.get('info') || '',
                    lyrics: formData.get('lyrics') || ''
                };

                try {
                    const updateResponse = await fetch(`/api/songs/${id}`, {
                        method: 'PUT',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(updateData)
                    });

                    if (!updateResponse.ok) {
                        throw new Error('Không thể cập nhật bài hát');
                    }

                    modalInstance.hide();
                    modal.remove();
                    await this.fetchSongs();
                    alert('Cập nhật bài hát thành công!');
                } catch (error) {
                    console.error('Lỗi khi cập nhật bài hát:', error);
                    alert('Có lỗi xảy ra khi cập nhật bài hát: ' + error.message);
                }
            });

            // Xử lý sự kiện đóng modal
            modal.addEventListener('hidden.bs.modal', () => {
                modal.remove();
            });
        } catch (error) {
            console.error('Lỗi khi sửa bài hát:', error);
            alert('Có lỗi xảy ra khi sửa bài hát: ' + error.message);
        }
    },

    // Hàm khởi tạo
    init() {
        // Tải danh sách bài hát
        this.fetchSongs();
        
        // Tải các danh sách khác
        loadArtistSelect();
        loadAlbumSelect();
        loadGenreSelect();

        // Xử lý form thêm bài hát
        const addSongForm = document.getElementById('addSongForm');
        if (addSongForm) {
            addSongForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                const formData = new FormData(addSongForm);
                
                try {
                    // Upload files
                    const uploadResponse = await fetch('/api/upload', {
                        method: 'POST',
                        body: formData
                    });
                    
                    if (!uploadResponse.ok) {
                        throw new Error('Lỗi khi tải file lên');
                    }
                    
                    const uploadResult = await uploadResponse.json();
                    
                    // Tạo object dữ liệu bài hát
                    const songData = {
                        title: formData.get('title'),
                        artist_id: formData.get('artist_id'),
                        album_id: formData.get('album_id') || null,
                        genre_id: formData.get('genre_id') || null,
                        file_url: uploadResult.file_url,
                        image_url: uploadResult.image_url || null,
                        info: formData.get('info') || '',
                        lyrics: formData.get('lyrics') || ''
                    };

                    // Thêm bài hát vào database
                    const songResponse = await fetch('/api/songs', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(songData)
                    });

                    if (!songResponse.ok) {
                        throw new Error('Lỗi khi thêm bài hát');
                    }

                    alert('Thêm bài hát thành công!');
                    addSongForm.reset();
                    const imagePreview = document.getElementById('imagePreview');
                    if (imagePreview) {
                        imagePreview.classList.add('d-none');
                    }
                    await this.fetchSongs();
                } catch (error) {
                    console.error('Lỗi:', error);
                    alert('Có lỗi xảy ra: ' + error.message);
                }
            });
        }

        // Xử lý nút refresh
        const refreshBtn = document.getElementById('refreshBtn');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => this.fetchSongs());
        }

        // Xử lý các form và event listeners khác
        this.initializeOtherListeners();
    },

    // Thêm method mới để xử lý các listeners khác
    initializeOtherListeners() {
        // Thêm event listener cho form thêm album
        const addAlbumForm = document.getElementById('addAlbumForm');
        if (addAlbumForm) {
            addAlbumForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                await addAlbum(e);
            });
        }

        // Thêm event listener cho form thêm thể loại
        const addGenreForm = document.getElementById('addGenreForm');
        if (addGenreForm) {
            addGenreForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                await addGenre(e);
            });
        }

        // Thêm event listener cho form thêm nghệ sĩ
        const addArtistForm = document.getElementById('addArtistForm');
        if (addArtistForm) {
            addArtistForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                await addArtist(e);
            });
        }

        // Thêm event listener cho các nút làm mới
        const refreshAlbumsBtn = document.getElementById('refreshAlbums');
        if (refreshAlbumsBtn) {
            refreshAlbumsBtn.addEventListener('click', fetchAlbums);
        }

        const refreshGenresBtn = document.getElementById('refreshGenres');
        if (refreshGenresBtn) {
            refreshGenresBtn.addEventListener('click', fetchGenres);
        }

        // Xử lý chuyển tab
        const tabButtons = document.querySelectorAll('.tab-button');
        const tabContents = document.querySelectorAll('.tab-content');

        tabButtons.forEach(button => {
            button.addEventListener('click', () => {
                const tabId = button.getAttribute('data-tab');
                
                // Remove active class from all buttons and contents
                tabButtons.forEach(btn => btn.classList.remove('active'));
                tabContents.forEach(content => content.classList.remove('active'));
                
                // Add active class to clicked button and corresponding content
                button.classList.add('active');
                document.getElementById(tabId).classList.add('active');
            });
        });

        // Tải dữ liệu ban đầu
        fetchAlbums();
        fetchGenres();
        fetchArtists();
    }
};

// Hàm lấy danh sách album
async function fetchAlbums() {
    try {
        const response = await fetch('/api/albums');
        if (!response.ok) {
            throw new Error('Không thể lấy danh sách album');
        }
        const albums = await response.json();
        renderAlbumList(albums);
    } catch (error) {
        console.error('Lỗi khi lấy danh sách album:', error);
        showError('albumList', 'Không thể tải danh sách album');
    }
}

// Hàm lấy danh sách thể loại
async function fetchGenres() {
    const genreList = document.getElementById('genreList');
    if (!genreList) return;

    try {
        const response = await fetch('/api/genres');
        console.log('Response status:', response.status);
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || 'Không thể lấy danh sách thể loại');
        }

        const genres = await response.json();
        console.log('Genres data:', genres);

        if (genres.length === 0) {
            genreList.innerHTML = '<li class="empty-message">Chưa có thể loại nào</li>';
            return;
        }

        genreList.innerHTML = genres.map(genre => `
            <li>
                <span class="item-name">${genre.name}</span>
                <div class="item-actions">
                    <button class="edit-btn" onclick="editGenre(${genre.id})">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="delete-btn" onclick="deleteGenre(${genre.id})">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </li>
        `).join('');
    } catch (error) {
        console.error('Lỗi khi lấy danh sách thể loại:', error);
        genreList.innerHTML = `
            <li class="error-message">
                ${error.message}
                <button onclick="fetchGenres()">Thử lại</button>
            </li>
        `;
    }
}

// Hàm hiển thị danh sách album
function renderAlbumList(albums) {
    const albumList = document.getElementById('albumList');
    if (!albumList) return;

    if (!Array.isArray(albums) || albums.length === 0) {
        albumList.innerHTML = `
            <li class="list-group-item text-center py-4">
                <div class="empty-message">
                    <i class="fas fa-compact-disc fa-2x mb-3"></i>
                    <p>Chưa có album nào</p>
                </div>
            </li>
        `;
        return;
    }

    albumList.innerHTML = albums.map(album => `
        <li class="list-group-item d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
                ${album.image_url ? 
                    `<img src="${album.image_url}" alt="${album.name}" class="me-3" style="width: 50px; height: 50px; object-fit: cover; border-radius: 4px;">` : 
                    '<div class="me-3" style="width: 50px; height: 50px; background: #eee; display: flex; align-items: center; justify-content: center; border-radius: 4px;"><i class="fas fa-compact-disc"></i></div>'
                }
                <div>
                    <h6 class="mb-0">${album.name}</h6>
                    <small class="text-muted">Tạo ngày: ${new Date(album.created_at).toLocaleDateString()}</small>
                </div>
            </div>
            <div class="btn-group">
                <button class="btn btn-sm btn-primary" onclick="editAlbum(${album.id})">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-sm btn-danger" onclick="deleteAlbum(${album.id})">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </li>
    `).join('');
}

// Hàm hiển thị danh sách thể loại
function renderGenreList(genres) {
    const genreList = document.getElementById('genreList');
    if (!genreList) return;

    if (genres.length === 0) {
        genreList.innerHTML = '<li class="empty-message">Chưa có thể loại nào</li>';
        return;
    }

    genreList.innerHTML = genres.map(genre => `
        <li>
            <span class="item-name">${genre.name}</span>
            <div class="item-actions">
                <button class="edit-btn" onclick="editGenre(${genre.id})">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="delete-btn" onclick="deleteGenre(${genre.id})">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </li>
    `).join('');
}

// Hàm xóa album
async function deleteAlbum(id) {
    if (!confirm('Bạn có chắc muốn xóa album này?')) return;

    try {
        const response = await fetch(`/api/albums/${id}`, {
            method: 'DELETE'
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Không thể xóa album');
        }

        alert('Đã xóa album thành công');
        fetchAlbums(); // Tải lại danh sách
    } catch (error) {
        console.error('Lỗi khi xóa album:', error);
        alert(error.message);
    }
}

// Hàm xóa thể loại
async function deleteGenre(id) {
    if (!confirm('Bạn có chắc muốn xóa thể loại này?')) return;

    try {
        const response = await fetch(`/api/genres/${id}`, {
            method: 'DELETE'
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Không thể xóa thể loại');
        }

        alert('Đã xóa thể loại thành công');
        fetchGenres(); // Tải lại danh sách
    } catch (error) {
        console.error('Lỗi khi xóa thể loại:', error);
        alert(error.message);
    }
}

// Hàm chỉnh sửa album
async function editAlbum(id) {
    const newName = prompt('Nhập tên mới cho album:');
    if (!newName) return;

    try {
        const response = await fetch(`/api/albums/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name: newName })
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Không thể cập nhật album');
        }

        alert('Đã cập nhật album thành công');
        fetchAlbums(); // Tải lại danh sách
    } catch (error) {
        console.error('Lỗi khi cập nhật album:', error);
        alert(error.message);
    }
}

// Hàm chỉnh sửa thể loại
async function editGenre(id) {
    const newName = prompt('Nhập tên mới cho thể loại:');
    if (!newName) return;

    try {
        const response = await fetch(`/api/genres/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name: newName })
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Không thể cập nhật thể loại');
        }

        alert('Đã cập nhật thể loại thành công');
        fetchGenres(); // Tải lại danh sách
    } catch (error) {
        console.error('Lỗi khi cập nhật thể loại:', error);
        alert('Không thể cập nhật thể loại');
    }
}

// Hàm hiển thị lỗi
function showError(elementId, message) {
    const element = document.getElementById(elementId);
    if (element) {
        element.innerHTML = `
            <li class="error-message">
                ${message}
                <button onclick="retry('${elementId}')">Thử lại</button>
            </li>
        `;
    }
}

// Hàm thử lại
function retry(elementId) {
    if (elementId === 'albumList') {
        fetchAlbums();
    } else if (elementId === 'genreList') {
        fetchGenres();
    }
}

// Thêm event listener cho nút làm mới
document.getElementById('refreshAlbums')?.addEventListener('click', fetchAlbums);
document.getElementById('refreshGenres')?.addEventListener('click', fetchGenres);

// Thêm biến để lưu trữ danh sách nghệ sĩ
let artists = [];

// Hàm lấy danh sách nghệ sĩ
async function fetchArtists() {
    try {
        const response = await fetch('/api/artists');
        if (!response.ok) {
            throw new Error('Không thể lấy danh sách nghệ sĩ');
        }
        const artists = await response.json();
        displayArtists(artists);
    } catch (error) {
        console.error('Lỗi:', error);
        alert('Có lỗi xảy ra khi lấy danh sách nghệ sĩ');
    }
}

// Hàm hiển thị danh sách nghệ sĩ
function displayArtists(artists) {
    const artistList = document.getElementById('artistList');
    artistList.innerHTML = '';
    
    if (artists.length === 0) {
        artistList.innerHTML = '<div class="list-group-item">Chưa có nghệ sĩ nào</div>';
        return;
    }
    
    artists.forEach(artist => {
        const artistElement = document.createElement('div');
        artistElement.className = 'list-group-item';
        artistElement.innerHTML = `
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="mb-1">${artist.name}</h5>
                    ${artist.country ? `<p class="mb-1"><strong>Quốc gia:</strong> ${artist.country}</p>` : ''}
                    ${artist.description ? `<p class="mb-0 text-muted">${artist.description}</p>` : ''}
                </div>
                <div>
                    <button class="btn btn-warning btn-sm me-2" onclick="editArtist(${artist.id})">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-danger btn-sm" onclick="deleteArtist(${artist.id})">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `;
        artistList.appendChild(artistElement);
    });
}

// Hàm thêm nghệ sĩ mới
async function addArtist(event) {
    event.preventDefault();
    
    // Lấy giá trị từ form
    const artistData = {
        name: document.getElementById('artistName').value,
        country: document.getElementById('artistCountry').value,
        description: document.getElementById('artistDescription').value
    };

    if (!artistData.name) {
        alert('Vui lòng nhập tên nghệ sĩ');
        return;
    }

    try {
        const response = await fetch('/api/artists', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(artistData)
        });

        if (!response.ok) {
            throw new Error('Không thể thêm nghệ sĩ');
        }

        document.getElementById('addArtistForm').reset();
        await fetchArtists(); // Tải lại danh sách
        alert('Thêm nghệ sĩ thành công');
    } catch (error) {
        console.error('Lỗi:', error);
        alert('Có lỗi xảy ra khi thêm nghệ sĩ');
    }
}

// Hàm xóa nghệ sĩ
async function deleteArtist(id) {
    if (!confirm('Bạn có chắc chắn muốn xóa nghệ sĩ này?')) {
        return;
    }

    try {
        const response = await fetch(`/api/artists/${id}`, {
            method: 'DELETE'
        });

        if (!response.ok) {
            throw new Error('Không thể xóa nghệ sĩ');
        }

        fetchArtists();
        alert('Xóa nghệ sĩ thành công');
    } catch (error) {
        console.error('Lỗi:', error);
        alert('Có lỗi xảy ra khi xóa nghệ sĩ');
    }
}

// Thêm event listener cho form thêm nghệ sĩ
document.addEventListener('DOMContentLoaded', () => {
    AdminFunctions.init();
});

// Hàm tải danh sách nghệ sĩ cho select
async function loadArtistSelect() {
    try {
        const response = await fetch('/api/artists');
        if (!response.ok) {
            throw new Error('Không thể lấy danh sách nghệ sĩ');
        }
        const artists = await response.json();
        const select = document.getElementById('artist');
        if (!select) {
            console.error('Không tìm thấy phần tử select nghệ sĩ');
            return;
        }
        select.innerHTML = '<option value="">Chọn nghệ sĩ</option>';
        artists.forEach(artist => {
            select.innerHTML += `<option value="${artist.id}">${artist.name}</option>`;
        });
        console.log('Đã tải danh sách nghệ sĩ:', artists);
    } catch (error) {
        console.error('Lỗi khi tải danh sách nghệ sĩ:', error);
    }
}

// Hàm tải danh sách album cho select
async function loadAlbumSelect() {
    try {
        const response = await fetch('/api/albums');
        const albums = await response.json();
        const select = document.getElementById('album');
        select.innerHTML = '<option value="">Chọn album</option>';
        albums.forEach(album => {
            select.innerHTML += `<option value="${album.id}">${album.name}</option>`;
        });
    } catch (error) {
        console.error('Lỗi khi tải danh sách album:', error);
    }
}

// Hàm tải danh sách thể loại cho select
async function loadGenreSelect() {
    try {
        const response = await fetch('/api/genres');
        const genres = await response.json();
        const select = document.getElementById('genre');
        select.innerHTML = '<option value="">Chọn thể loại</option>';
        genres.forEach(genre => {
            select.innerHTML += `<option value="${genre.id}">${genre.name}</option>`;
        });
    } catch (error) {
        console.error('Lỗi khi tải danh sách thể loại:', error);
    }
}

// Hàm thêm album mới
async function addAlbum(event) {
    event.preventDefault();
    
    const albumName = document.getElementById('albumName').value;
    const albumImage = document.getElementById('albumImage').files[0];
    
    if (!albumName) {
        alert('Vui lòng nhập tên album');
        return;
    }

    const formData = new FormData();
    formData.append('name', albumName);
    if (albumImage) {
        formData.append('albumImage', albumImage);
    }

    try {
        const response = await fetch('/api/albums', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            throw new Error('Không thể thêm album');
        }

        document.getElementById('addAlbumForm').reset();
        document.getElementById('albumImagePreview').classList.add('d-none');
        await fetchAlbums();
        alert('Thêm album thành công');
    } catch (error) {
        console.error('Lỗi:', error);
        alert('Có lỗi xảy ra khi thêm album');
    }
}

// Xử lý preview ảnh album
document.getElementById('albumImage')?.addEventListener('change', function(e) {
    const preview = document.getElementById('albumImagePreview');
    const file = e.target.files[0];
    
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            preview.src = e.target.result;
            preview.classList.remove('d-none');
        }
        reader.readAsDataURL(file);
    } else {
        preview.classList.add('d-none');
    }
});

// Hàm thêm thể loại mới
async function addGenre(event) {
    event.preventDefault();
    
    const genreName = document.getElementById('genreName').value;
    if (!genreName) {
        alert('Vui lòng nhập tên thể loại');
        return;
    }

    try {
        const response = await fetch('/api/genres', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name: genreName })
        });

        if (!response.ok) {
            throw new Error('Không thể thêm thể loại');
        }

        document.getElementById('addGenreForm').reset();
        await fetchGenres();
        alert('Thêm thể loại thành công');
    } catch (error) {
        console.error('Lỗi:', error);
        alert('Có lỗi xảy ra khi thêm thể loại');
    }
}

// Hàm chỉnh sửa nghệ sĩ
async function editArtist(id) {
    const newName = prompt('Nhập tên mới cho nghệ sĩ:');
    if (!newName) return;

    try {
        const response = await fetch(`/api/artists/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name: newName })
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Không thể cập nhật nghệ sĩ');
        }

        alert('Đã cập nhật nghệ sĩ thành công');
        fetchArtists(); // Tải lại danh sách
    } catch (error) {
        console.error('Lỗi khi cập nhật nghệ sĩ:', error);
        alert('Có lỗi xảy ra khi cập nhật nghệ sĩ');
    }
} 