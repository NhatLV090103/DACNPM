<div class="sidebar">
    <div class="list-group">
        <a href="index.php" class="list-group-item list-group-item-action">
            <i class="fas fa-home me-2"></i> Trang chủ
        </a>
        <a href="?page=trending" class="list-group-item list-group-item-action">
            <i class="fas fa-fire me-2"></i> Thịnh hành
        </a>
        <a href="?page=new" class="list-group-item list-group-item-action">
            <i class="fas fa-music me-2"></i> Mới phát hành
        </a>
        <?php if (isLoggedIn()): ?>
            <a href="?page=favorites" class="list-group-item list-group-item-action">
                <i class="fas fa-heart me-2"></i> Yêu thích
            </a>
            <a href="?page=history" class="list-group-item list-group-item-action">
                <i class="fas fa-history me-2"></i> Lịch sử
            </a>
        <?php endif; ?>
    </div>

    <?php if (isLoggedIn()): ?>
    <div class="mt-4">
        <h6 class="sidebar-heading px-3 mt-4 mb-1 text-muted">
            <span>Playlist của bạn</span>
            <a href="?page=create-playlist" class="link-secondary float-end">
                <i class="fas fa-plus-circle"></i>
            </a>
        </h6>
        <div class="list-group">
            <?php
            // TODO: Add code to fetch and display user playlists
            ?>
        </div>
    </div>
    <?php endif; ?>
</div>
