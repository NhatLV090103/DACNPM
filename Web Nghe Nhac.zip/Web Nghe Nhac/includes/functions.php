<?php
// Function to get all songs
function getAllSongs($db) {
    $query = "SELECT * FROM songs ORDER BY created_at DESC";
    $stmt = $db->prepare($query);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Function to get song by ID
function getSongById($db, $id) {
    $query = "SELECT * FROM songs WHERE id = ?";
    $stmt = $db->prepare($query);
    $stmt->execute([$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// Function to search songs
function searchSongs($db, $keyword) {
    $query = "SELECT * FROM songs WHERE title LIKE ? OR artist LIKE ?";
    $stmt = $db->prepare($query);
    $keyword = "%$keyword%";
    $stmt->execute([$keyword, $keyword]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Function to check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Function to get user by ID
function getUserById($db, $id) {
    $query = "SELECT * FROM users WHERE id = ?";
    $stmt = $db->prepare($query);
    $stmt->execute([$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}
