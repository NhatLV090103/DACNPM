<header class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="index.php">Clone Music</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Trang chủ</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="?page=browse">Khám phá</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="?page=playlist">Playlist</a>
                </li>
            </ul>
            <form class="d-flex me-3" action="?page=search" method="GET">
                <input class="form-control me-2" type="search" name="keyword" placeholder="Tìm kiếm bài hát...">
                <button class="btn btn-outline-light" type="submit">Tìm</button>
            </form>
            <?php if (isLoggedIn()): ?>
                <div class="dropdown">
                    <button class="btn btn-outline-light dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown">
                        <?php 
                        $user = getUserById($db, $_SESSION['user_id']);
                        echo htmlspecialchars($user['username']);
                        ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="?page=profile">Hồ sơ</a></li>
                        <li><a class="dropdown-item" href="?page=logout">Đăng xuất</a></li>
                    </ul>
                </div>
            <?php else: ?>
                <div class="navbar-nav">
                    <a class="nav-link" href="?page=login">Đăng nhập</a>
                    <a class="nav-link" href="?page=register">Đăng ký</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</header>
