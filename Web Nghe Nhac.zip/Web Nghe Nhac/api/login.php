<?php
header('Content-Type: application/json');

require_once '../config/database.php';
require_once '../config/jwt_utils.php';

// Lấy dữ liệu từ request
$data = json_decode(file_get_contents('php://input'), true);
$username = $data['username'] ?? '';
$password = $data['password'] ?? '';

if (empty($username) || empty($password)) {
    http_response_code(400);
    echo json_encode(['error' => 'Vui lòng nhập đầy đủ thông tin']);
    exit();
}

try {
    // Kiểm tra thông tin đăng nhập
    $stmt = $conn->prepare("SELECT id, username, password FROM users WHERE username = ? AND status = 1");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        throw new Exception('Tên đăng nhập hoặc mật khẩu không đúng');
    }
    
    $user = $result->fetch_assoc();
    
    // Xác thực mật khẩu
    if (!password_verify($password, $user['password'])) {
        throw new Exception('Tên đăng nhập hoặc mật khẩu không đúng');
    }
    
    // Tạo JWT token
    $token = JWT::encode([
        'userId' => $user['id'],
        'username' => $user['username'],
        'exp' => time() + (24 * 60 * 60) // 24 giờ
    ], JWT_SECRET_KEY);
    
    // Trả về thông tin đăng nhập thành công
    echo json_encode([
        'message' => 'Đăng nhập thành công',
        'userId' => $user['id'],
        'username' => $user['username'],
        'token' => $token
    ]);
    
} catch (Exception $e) {
    http_response_code(401);
    echo json_encode([
        'error' => $e->getMessage()
    ]);
} 