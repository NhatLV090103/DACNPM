<?php
header('Content-Type: application/json');

require_once '../config/database.php';
require_once '../config/jwt_utils.php';

// Lấy token từ header
$headers = apache_request_headers();
$auth_header = isset($headers['Authorization']) ? $headers['Authorization'] : '';

if (empty($auth_header) || !preg_match('/Bearer\s+(.*)$/i', $auth_header, $matches)) {
    http_response_code(401);
    echo json_encode(['error' => 'Token không hợp lệ hoặc không tồn tại']);
    exit();
}

$token = $matches[1];

try {
    // Xác thực JWT token
    $decoded = JWT::decode($token, JWT_SECRET_KEY, array('HS256'));
    
    // Kiểm tra user trong database
    $stmt = $conn->prepare("SELECT id, username FROM users WHERE id = ? AND status = 1");
    $stmt->bind_param("i", $decoded->userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        throw new Exception('Người dùng không tồn tại hoặc đã bị vô hiệu hóa');
    }
    
    $user = $result->fetch_assoc();
    
    // Tạo token mới để làm mới session
    $new_token = JWT::encode([
        'userId' => $user['id'],
        'username' => $user['username'],
        'exp' => time() + (24 * 60 * 60) // 24 giờ
    ], JWT_SECRET_KEY);
    
    echo json_encode([
        'valid' => true,
        'token' => $new_token,
        'user' => [
            'id' => $user['id'],
            'username' => $user['username']
        ]
    ]);
    
} catch (Exception $e) {
    http_response_code(401);
    echo json_encode([
        'error' => 'Session không hợp lệ',
        'message' => $e->getMessage()
    ]);
} 