// Wait for the document to be ready
$(document).ready(function() {
    // Handle active navigation links
    const currentPage = new URLSearchParams(window.location.search).get('page') || 'home';
    $(`.nav-link[href$="${currentPage}"]`).addClass('active');
    
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Handle favorite button clicks
    $('.btn-favorite').click(function(e) {
        e.preventDefault();
        const songId = $(this).data('song-id');
        // TODO: Implement favorite functionality
        $(this).toggleClass('active');
    });

    // Handle playlist add button clicks
    $('.btn-add-to-playlist').click(function(e) {
        e.preventDefault();
        const songId = $(this).data('song-id');
        // TODO: Implement add to playlist functionality
    });
});
