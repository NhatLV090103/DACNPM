-- Tạo database nightmare nếu chưa tồn tại trong hệ thống
CREATE DATABASE IF NOT EXISTS nightmare CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
-- Chọn database nightmare để sử dụng
USE nightmare;

-- Tạo bảng artists để lưu thông tin về nghệ sĩ
CREATE TABLE IF NOT EXISTS artists (
    id INT AUTO_INCREMENT PRIMARY KEY,    -- ID tự động tăng, là khóa chính
    name VARCHAR(255) NOT NULL,          -- Tên nghệ sĩ, không được trống
    country VARCHAR(255),                -- Quốc gia của nghệ sĩ
    description TEXT,                    -- Thông tin mô tả về nghệ sĩ
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,  -- Thời gian tạo
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP  -- Thời gian cập nhật
);

-- Tạo bảng genres để lưu trữ các thể loại nhạc
CREATE TABLE IF NOT EXISTS genres (
    id INT AUTO_INCREMENT PRIMARY KEY,    -- ID tự động tăng, là khóa chính
    name VARCHAR(255) NOT NULL,          -- Tên thể loại, không được trống
    description TEXT,                    -- Mô tả về thể loại
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,  -- Thời gian tạo
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP  -- Thời gian cập nhật
);

-- Tạo bảng albums để lưu trữ các album
CREATE TABLE IF NOT EXISTS albums (
    id INT AUTO_INCREMENT PRIMARY KEY,    -- ID tự động tăng, là khóa chính
    name VARCHAR(255) NOT NULL,          -- Tên album, không được trống
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,  -- Thời gian tạo
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP  -- Thời gian cập nhật
);

-- Tạo bảng users để lưu thông tin người dùng
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,    -- ID tự động tăng, là khóa chính
    username VARCHAR(255) NOT NULL UNIQUE, -- Tên đăng nhập, không trùng lặp
    email VARCHAR(255) NOT NULL UNIQUE,   -- Email, không trùng lặp
    password VARCHAR(255) NOT NULL,       -- Mật khẩu đã được mã hóa
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,  -- Thời gian tạo tài khoản
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP  -- Thời gian cập nhật
);

-- Tạo bảng songs để lưu trữ thông tin các bài hát
CREATE TABLE IF NOT EXISTS songs (
    id INT AUTO_INCREMENT PRIMARY KEY,    -- ID tự động tăng, là khóa chính
    title VARCHAR(255) NOT NULL,         -- Tên bài hát, không được để trống
    artist_id INT,                       -- ID của nghệ sĩ, có thể để trống
    album_id INT,                        -- ID của album, có thể để trống
    genre_id INT,                        -- ID của thể loại, có thể để trống
    image_url VARCHAR(255),              -- Đường dẫn đến file ảnh, có thể để trống
    file_url VARCHAR(255) NOT NULL,      -- Đường dẫn đến file nhạc, không được để trống
    info TEXT,                           -- Thông tin thêm về bài hát, có thể để trống
    lyrics TEXT,                         -- Lời bài hát, có thể để trống
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,  -- Thời gian tạo
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,  -- Thời gian cập nhật
    FOREIGN KEY (artist_id) REFERENCES artists(id) ON DELETE SET NULL,  -- Liên kết với bảng artists
    FOREIGN KEY (album_id) REFERENCES albums(id) ON DELETE SET NULL,    -- Liên kết với bảng albums
    FOREIGN KEY (genre_id) REFERENCES genres(id) ON DELETE SET NULL     -- Liên kết với bảng genres
);

-- Tạo bảng binhluan để lưu trữ các bình luận của người dùng về bài hát
CREATE TABLE IF NOT EXISTS binhluan (
    id INT AUTO_INCREMENT PRIMARY KEY,    -- ID tự động tăng, là khóa chính
    song_id INT NOT NULL,                -- ID của bài hát được bình luận
    user_id INT NOT NULL,                -- ID của người bình luận
    comment TEXT NOT NULL,               -- Nội dung bình luận
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,  -- Thời gian bình luận
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,  -- Thời gian cập nhật
    FOREIGN KEY (song_id) REFERENCES songs(id) ON DELETE CASCADE,     -- Liên kết với bảng songs
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE      -- Liên kết với bảng users
);

-- Tạo bảng favorites để lưu trữ các bài hát yêu thích của người dùng
CREATE TABLE IF NOT EXISTS favorites (
    id INT AUTO_INCREMENT PRIMARY KEY,    -- ID tự động tăng, là khóa chính
    user_id INT NOT NULL,                -- ID của người dùng
    song_id INT NOT NULL,                -- ID của bài hát được yêu thích
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,  -- Thời gian thêm vào yêu thích
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,  -- Thời gian cập nhật
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,     -- Liên kết với bảng users
    FOREIGN KEY (song_id) REFERENCES songs(id) ON DELETE CASCADE,     -- Liên kết với bảng songs
    UNIQUE KEY unique_favorite (user_id, song_id)   -- Đảm bảo mỗi user chỉ yêu thích một bài hát một lần
);