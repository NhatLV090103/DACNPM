<?php
$recent_songs = getAllSongs($db);
?>

<h2 class="mb-4">Bài hát mới nhất</h2>

<div class="row row-cols-1 row-cols-md-3 g-4">
    <?php foreach ($recent_songs as $song): ?>
    <div class="col">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title"><?php echo htmlspecialchars($song['title']); ?></h5>
                <p class="card-text">
                    <small class="text-muted">
                        <i class="fas fa-user me-1"></i>
                        <?php echo htmlspecialchars($song['artist']); ?>
                    </small>
                </p>
                <audio class="w-100" controls>
                    <source src="<?php echo htmlspecialchars($song['file_url']); ?>" type="audio/mpeg">
                    Your browser does not support the audio element.
                </audio>
            </div>
            <div class="card-footer">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="btn-group">
                        <button type="button" class="btn btn-sm btn-outline-secondary">
                            <i class="fas fa-heart"></i>
                        </button>
                        <button type="button" class="btn btn-sm btn-outline-secondary">
                            <i class="fas fa-plus"></i>
                        </button>
                    </div>
                    <small class="text-muted">
                        <?php echo date('d/m/Y', strtotime($song['created_at'])); ?>
                    </small>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>
