const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
const path = require('path');
const multer = require('multer');
const fetch = require('node-fetch');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { exec } = require('child_process');

const app = express();
const port = 3000;

// JWT Secret Key
const JWT_SECRET_KEY = 'your-secret-key-123';

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Cho phép truy cập tĩnh đến thư mục 'songs' và 'public'
app.use('/songs', express.static(path.join(__dirname, 'songs')));
app.use('/images', express.static(path.join(__dirname, 'images')));
app.use(express.static('public'));

// Kết nối MySQL với promise
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',      
  password: '',   
  database: 'nightmare',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
//  debug: false, // Tắt debug logs
  multipleStatements: true // Cho phép thực hiện nhiều câu query
});

// Test kết nối
pool.getConnection()
    .then(conn => {
    console.log('Kết nối MySQL thành công');
        conn.release();
    })
    .catch(err => {
    console.error('Lỗi kết nối MySQL:', err);
});

// // Test kết nối và khởi tạo database
// async function initializeDatabase() {
//     let conn;
//     try {
//         console.log('=== Bắt đầu khởi tạo database ===');
//         conn = await pool.getConnection();
        
//         // Kiểm tra và tạo database nếu chưa tồn tại
//         await conn.query('CREATE DATABASE IF NOT EXISTS nightmare');
//         await conn.query('USE nightmare');
//         console.log('✅ Database OK');

//         // Tạo bảng artists
//         await conn.query(`
//             CREATE TABLE IF NOT EXISTS artists (
//                 id INT PRIMARY KEY AUTO_INCREMENT,
//                 name VARCHAR(255) NOT NULL,
//                 country VARCHAR(100),
//                 description TEXT,
//                 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
//                 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
//             )
//         `);
//         console.log('✅ Bảng artists OK');

//         // Tạo bảng albums
//         await conn.query(`
//             CREATE TABLE IF NOT EXISTS albums (
//                 id INT PRIMARY KEY AUTO_INCREMENT,
//                 name VARCHAR(255) NOT NULL,
//                 image_url VARCHAR(255),
//                 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
//                 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
//             )
//         `);
//         console.log('✅ Bảng albums OK');

//         // Tạo bảng genres
//         await conn.query(`
//             CREATE TABLE IF NOT EXISTS genres (
//                 id INT PRIMARY KEY AUTO_INCREMENT,
//                 name VARCHAR(255) NOT NULL,
//                 description TEXT,
//                 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
//                 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
//             )
//         `);
//         console.log('✅ Bảng genres OK');

//         // Tạo bảng songs
//         try {
//             console.log('Đang tạo bảng songs...');
//             await conn.query(`
//                 CREATE TABLE IF NOT EXISTS songs (
//                     id INT PRIMARY KEY AUTO_INCREMENT,
//                     title VARCHAR(255) NOT NULL,
//                     artist_id INT,
//                     album_id INT,
//                     genre_id INT,
//                     file_url VARCHAR(255) NOT NULL,
//                     image_url VARCHAR(255),
//                     lyrics TEXT,
//                     info TEXT,
//                     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
//                     updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
//                     FOREIGN KEY (artist_id) REFERENCES artists(id) ON DELETE SET NULL,
//                     FOREIGN KEY (album_id) REFERENCES albums(id) ON DELETE SET NULL,
//                     FOREIGN KEY (genre_id) REFERENCES genres(id) ON DELETE SET NULL
//                 )
//             `);
//             console.log('✅ Bảng songs đã được tạo thành công');

//             // Kiểm tra cấu trúc bảng
//             const [columns] = await conn.query('SHOW COLUMNS FROM songs');
//             console.log('Cấu trúc bảng songs:', columns);

//         } catch (error) {
//             console.error('❌ Lỗi khi tạo bảng songs:', error);
//             throw error;
//         }

//         // Kiểm tra dữ liệu
//         const [artists] = await conn.query('SELECT * FROM artists');
//         const [albums] = await conn.query('SELECT * FROM albums');
//         const [genres] = await conn.query('SELECT * FROM genres');
//         const [songs] = await conn.query('SELECT * FROM songs');

//         console.log('Thống kê dữ liệu:');
//         console.log('- Artists:', artists.length);
//         console.log('- Albums:', albums.length);
//         console.log('- Genres:', genres.length);
//         console.log('- Songs:', songs.length);

//         console.log('=== Khởi tạo database hoàn tất ===');
//     } catch (error) {
//         console.error('❌ Lỗi khởi tạo database:', error);
//         throw error;
//     } finally {
//         if (conn) conn.release();
//     }
// }

// // Khởi tạo database khi start server
// initializeDatabase()
//     .then(() => {
//         console.log('✅ Khởi tạo database thành công');
//     })
//     .catch(error => {
//         console.error('❌ Lỗi khởi tạo database:', error);
//         process.exit(1);
// });

// Cấu hình multer để lưu file vào các thư mục tương ứng
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    let uploadPath;
    if (file.fieldname === 'songFile') {
      uploadPath = path.join(__dirname, 'songs');
    } else if (file.fieldname === 'imageFile' || file.fieldname === 'albumImage') {
      uploadPath = path.join(__dirname, 'images');
    } else {
      return cb(new Error('Sai fieldname khi upload file!'), null);
    }
    cb(null, uploadPath);
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname);
  }
});

const upload = multer({ 
  storage: storage,
  limits: {
    fileSize: 10 * 1024 * 1024 // Giới hạn 10MB
  }
});

// ===================== API Upload File =====================
app.post('/api/upload', upload.fields([
  { name: 'songFile', maxCount: 1 },
  { name: 'imageFile', maxCount: 1 }
]), (req, res) => {
  console.log('Files received:', req.files);

  if (!req.files || !req.files.songFile) {
    return res.status(400).json({ error: 'Không có file nhạc được tải lên' });
  }

  const response = {
    message: 'File tải lên thành công',
    file_url: 'songs/' + req.files.songFile[0].filename
  };

  // Xử lý file ảnh nếu có
  if (req.files.imageFile && req.files.imageFile[0]) {
    const imageFile = req.files.imageFile[0];
    console.log('Image file received:', imageFile);
    
    // Kiểm tra mime type của file ảnh
    if (!imageFile.mimetype.startsWith('image/')) {
      return res.status(400).json({ error: 'File không phải là ảnh' });
    }

    // Tạo đường dẫn ảnh
    response.image_url = 'images/' + imageFile.filename;
    console.log('Image URL created:', response.image_url);
  } else {
    console.log('No image file received');
  }

  // Log response trước khi gửi
  console.log('Final response:', response);
  res.json(response);
});

// ===================== API Quản lý Bài Hát =====================

// Middleware xác thực token
const authenticateToken = async (req, res, next) => {
    try {
        const authHeader = req.headers['authorization'];
        const token = authHeader && authHeader.split(' ')[1];

        if (!token) {
            return res.status(401).json({ error: 'Không tìm thấy token xác thực' });
        }

        const decoded = jwt.verify(token, JWT_SECRET_KEY);
        req.user = decoded;
        next();
    } catch (error) {
        console.error('Lỗi xác thực token:', error);
        return res.status(403).json({ error: 'Token không hợp lệ hoặc đã hết hạn' });
    }
};

// API lấy danh sách bài hát
app.get('/api/songs', async (req, res) => {
    let conn;
    try {
        console.log('=== Bắt đầu lấy danh sách bài hát ===');
        console.log('1. Kết nối database...');
        conn = await pool.getConnection();
        
        // Kiểm tra kết nối
        console.log('2. Kiểm tra kết nối...');
        await conn.query('SELECT 1');
        
        // Kiểm tra bảng songs
        console.log('3. Kiểm tra bảng songs...');
        const [tables] = await conn.query('SHOW TABLES LIKE "songs"');
        console.log('Kết quả kiểm tra bảng:', tables);

        if (tables.length === 0) {
            throw new Error('Bảng songs không tồn tại');
        }

        // Kiểm tra cấu trúc bảng
        console.log('4. Kiểm tra cấu trúc bảng...');
        const [columns] = await conn.query('SHOW COLUMNS FROM songs');
        console.log('Cấu trúc bảng:', columns);

        // Thực hiện query chính
        console.log('5. Thực hiện query chính...');
        const query = `
            SELECT 
                s.*,
                IFNULL(a.name, '') as artist_name,
                IFNULL(al.name, '') as album_name,
                IFNULL(g.name, '') as genre_name
            FROM songs s
            LEFT JOIN artists a ON s.artist_id = a.id
            LEFT JOIN albums al ON s.album_id = al.id
            LEFT JOIN genres g ON s.genre_id = g.id
            ORDER BY s.created_at DESC
        `;
        
        const [rows] = await conn.query(query);
        console.log('6. Query thành công, số bản ghi:', rows.length);

        // Format dữ liệu
        console.log('7. Format dữ liệu...');
        const formattedRows = rows.map(row => ({
            id: row.id,
            title: row.title || '',
            artist_id: row.artist_id,
            album_id: row.album_id,
            genre_id: row.genre_id,
            file_url: row.file_url || '',
            image_url: row.image_url || '',
            info: row.info || '',
            lyrics: row.lyrics || '',
            created_at: row.created_at,
            artist_name: row.artist_name || '',
            album_name: row.album_name || '',
            genre_name: row.genre_name || ''
        }));

        console.log('8. Trả về kết quả');
        res.json(formattedRows);
        console.log('=== Kết thúc lấy danh sách bài hát ===');

    } catch (error) {
        console.error('❌ Lỗi chi tiết:', {
            step: 'get /api/songs',
            message: error.message,
            code: error.code,
            errno: error.errno,
            sqlMessage: error.sqlMessage,
            sqlState: error.sqlState,
            stack: error.stack
        });
        
        let errorMessage = 'Lỗi khi lấy danh sách bài hát';
        
        if (error.code === 'ECONNREFUSED') {
            errorMessage = 'Không thể kết nối đến database. Vui lòng kiểm tra MySQL đã được khởi động chưa.';
        } else if (error.code === 'ER_NO_SUCH_TABLE') {
            errorMessage = 'Bảng songs không tồn tại. Vui lòng khởi động lại server để tạo database.';
        } else if (error.code === 'ER_BAD_DB_ERROR') {
            errorMessage = 'Database không tồn tại. Vui lòng khởi động lại server để tạo database.';
        } else if (error.code === 'ER_BAD_FIELD_ERROR') {
            errorMessage = 'Cấu trúc bảng songs không đúng. Vui lòng kiểm tra lại các cột trong bảng.';
        }
        
        res.status(500).json({ 
            error: errorMessage,
            details: error.sqlMessage || error.message
        });
    } finally {
        if (conn) {
            console.log('9. Đóng kết nối database');
            conn.release();
        }
    }
});

// API lấy chi tiết một bài hát
app.get('/api/songs/:id', async (req, res) => {
    try {
  const { id } = req.params;
  console.log('Đang lấy chi tiết bài hát id:', id);
  
        const conn = await pool.getConnection();
  const query = `
            SELECT 
                s.*,
                a.name as artist_name,
                al.name as album_name,
                g.name as genre_name
            FROM songs s
            LEFT JOIN artists a ON s.artist_id = a.id
            LEFT JOIN albums al ON s.album_id = al.id
            LEFT JOIN genres g ON s.genre_id = g.id
            WHERE s.id = ?
        `;

        const [rows] = await conn.query(query, [id]);
        
        if (rows.length === 0) {
      return res.status(404).json({ error: 'Không tìm thấy bài hát' });
    }

    // Format dữ liệu trước khi trả về
    const song = {
            ...rows[0],
            artist_name: rows[0].artist_name || '',
            album_name: rows[0].album_name || '',
            genre_name: rows[0].genre_name || '',
            lyrics: rows[0].lyrics || '',
            file_url: rows[0].file_url || '',
            image_url: rows[0].image_url || ''
    };

    console.log('Chi tiết bài hát:', song);
    res.json(song);
        
        conn.release();
    } catch (error) {
        console.error('Lỗi khi lấy chi tiết bài hát:', error);
        res.status(500).json({ error: 'Không thể lấy chi tiết bài hát' });
    }
});

// Thêm mới bài hát
app.post('/api/songs', async (req, res) => {
  console.log('Received song data:', req.body);

  const { title, artist_id, file_url, image_url, info, lyrics, genre_id, album_id } = req.body;

  if (!title || !file_url) {
    return res.status(400).json({ error: 'Tiêu đề và đường dẫn file là bắt buộc' });
  }

  try {
    const conn = await pool.getConnection();

    // Kiểm tra artist_id nếu được cung cấp
    if (artist_id) {
      const [artists] = await conn.query('SELECT id FROM artists WHERE id = ?', [artist_id]);
      if (artists.length === 0) {
        conn.release();
        return res.status(400).json({ error: 'Nghệ sĩ không tồn tại' });
      }
    }

  // Chuẩn bị dữ liệu để insert
  const insertData = {
    title,
      artist_id: artist_id || null,
    file_url,
      image_url: image_url || null,
    info: info || '',
      lyrics: lyrics || '',
      genre_id: genre_id || null,
      album_id: album_id || null
  };

  console.log('Data to be inserted:', insertData);

    // Tạo câu query động
  const fields = Object.keys(insertData);
  const values = Object.values(insertData);
  const placeholders = fields.map(() => '?').join(', ');
  const query = `INSERT INTO songs (${fields.join(', ')}) VALUES (${placeholders})`;

  console.log('SQL Query:', query);
  console.log('Values:', values);

    const [result] = await conn.query(query, values);
    
    // Lấy thông tin bài hát vừa thêm kèm theo tên nghệ sĩ
    const [songDetails] = await conn.query(`
      SELECT s.*, a.name as artist_name 
      FROM songs s 
      LEFT JOIN artists a ON s.artist_id = a.id 
      WHERE s.id = ?
    `, [result.insertId]);

    conn.release();
    res.json({ 
      message: 'Bài hát đã được thêm', 
      songId: result.insertId,
      songData: songDetails[0]
    });

  } catch (error) {
    console.error('Lỗi khi thêm bài hát:', error);
    res.status(500).json({ error: 'Không thể thêm bài hát' });
  }
});

// Cập nhật bài hát
app.put('/api/songs/:id', async (req, res) => {
  const { id } = req.params;
  const { title, artist_id, file_url, image_url, info, lyrics, genre_id, album_id } = req.body;

  if (!title || !file_url) {
    return res.status(400).json({ error: 'Tiêu đề và đường dẫn file là bắt buộc' });
  }

  try {
    const conn = await pool.getConnection();

    // Kiểm tra artist_id nếu được cung cấp
    if (artist_id) {
      const [artists] = await conn.query('SELECT id FROM artists WHERE id = ?', [artist_id]);
      if (artists.length === 0) {
        conn.release();
        return res.status(400).json({ error: 'Nghệ sĩ không tồn tại' });
      }
    }

    const query = `
      UPDATE songs 
      SET title = ?, 
          artist_id = ?, 
          file_url = ?, 
          image_url = ?, 
          info = ?, 
          lyrics = ?,
          genre_id = ?,
          album_id = ?
      WHERE id = ?
    `;

    await conn.query(query, [
      title, 
      artist_id || null, 
      file_url, 
      image_url || null, 
      info || '', 
      lyrics || '',
      genre_id || null,
      album_id || null,
      id
    ]);

    // Lấy thông tin bài hát sau khi cập nhật
    const [updatedSong] = await conn.query(`
      SELECT s.*, a.name as artist_name 
      FROM songs s 
      LEFT JOIN artists a ON s.artist_id = a.id 
      WHERE s.id = ?
    `, [id]);

    conn.release();
    res.json({ 
      message: 'Bài hát đã được cập nhật',
      songData: updatedSong[0]
    });

  } catch (error) {
    console.error('Lỗi khi cập nhật bài hát:', error);
    res.status(500).json({ error: 'Không thể cập nhật bài hát' });
  }
});

// Xoá bài hát
app.delete('/api/songs/:id', (req, res) => {
  const { id } = req.params;
  const query = 'DELETE FROM songs WHERE id = ?';
  pool.getConnection()
    .then(conn => {
      conn.query(query, [id])
        .then(() => {
          res.json({ message: 'Bài hát đã được xoá' });
        })
        .catch(err => {
          console.error('Lỗi khi xoá bài hát:', err);
      return res.status(500).json({ error: err.message });
        })
        .finally(() => {
          conn.release();
        });
    })
    .catch(err => {
      console.error('Lỗi kết nối database:', err);
      return res.status(500).json({ error: 'Lỗi kết nối database' });
    });
});

// API lấy danh sách thể loại
app.get('/api/genres', (req, res) => {
    pool.getConnection()
        .then(conn => {
            conn.query('SELECT * FROM genres')
                .then(([rows]) => {
                    console.log('Dữ liệu genres:', rows);
                    res.json(rows);
                })
                .catch(err => {
                    console.error('Lỗi truy vấn:', err);
                    res.status(500).json({ error: 'Lỗi truy vấn database' });
                })
                .finally(() => {
                    conn.release();
                });
        })
        .catch(err => {
            console.error('Lỗi kết nối:', err);
            res.status(500).json({ error: 'Lỗi kết nối database' });
        });
});

// API thêm thể loại
app.post("/api/genres", (req, res) => {
    const { name } = req.body;
    if (!name) {
        return res.status(400).json({ error: "Tên thể loại là bắt buộc" });
    }

    pool.getConnection()
        .then(conn => {
            conn.query("INSERT INTO genres (name) VALUES (?)", [name])
                .then(([result]) => {
                    res.json({ id: result.insertId, name });
                })
                .catch(err => {
                    console.error('Lỗi khi thêm thể loại:', err);
                    res.status(500).json({ error: err.message });
                })
                .finally(() => {
                    conn.release();
                });
        })
        .catch(err => {
            console.error('Lỗi kết nối database:', err);
            res.status(500).json({ error: 'Lỗi kết nối database' });
        });
});

// API cập nhật thể loại
app.put('/api/genres/:id', (req, res) => {
    const { id } = req.params;
    const { name } = req.body;

    if (!name) {
        return res.status(400).json({ error: 'Tên thể loại là bắt buộc' });
    }

    pool.getConnection()
        .then(conn => {
            conn.query('UPDATE genres SET name = ? WHERE id = ?', [name, id])
                .then(([result]) => {
                    if (result.affectedRows === 0) {
                        res.status(404).json({ error: 'Không tìm thấy thể loại' });
                    } else {
                        res.json({ message: 'Cập nhật thể loại thành công' });
                    }
                })
                .catch(err => {
                    console.error('Lỗi khi cập nhật thể loại:', err);
                    res.status(500).json({ error: 'Lỗi khi cập nhật thể loại' });
                })
                .finally(() => {
                    conn.release();
                });
        })
        .catch(err => {
            console.error('Lỗi kết nối database:', err);
            res.status(500).json({ error: 'Lỗi kết nối database' });
        });
});

// API xóa thể loại
app.delete('/api/genres/:id', (req, res) => {
    const { id } = req.params;

    pool.getConnection()
        .then(conn => {
            conn.query('DELETE FROM genres WHERE id = ?', [id])
                .then(([result]) => {
                    if (result.affectedRows === 0) {
                        res.status(404).json({ error: 'Không tìm thấy thể loại' });
                    } else {
                        res.json({ message: 'Xóa thể loại thành công' });
                    }
                })
                .catch(err => {
                    console.error('Lỗi khi xóa thể loại:', err);
                    res.status(500).json({ error: 'Lỗi khi xóa thể loại' });
                })
                .finally(() => {
                    conn.release();
                });
        })
        .catch(err => {
            console.error('Lỗi kết nối database:', err);
            res.status(500).json({ error: 'Lỗi kết nối database' });
        });
});

// API lấy danh sách album
app.get('/api/albums', async (req, res) => {
    let conn;
    try {
        conn = await pool.getConnection();
        const [albums] = await conn.query('SELECT * FROM albums ORDER BY created_at DESC');
        res.json(albums);
    } catch (error) {
        console.error('Lỗi khi lấy danh sách album:', error);
        res.status(500).json({ error: 'Không thể lấy danh sách album' });
    } finally {
        if (conn) conn.release();
    }
});

// API thêm album mới
app.post('/api/albums', upload.single('albumImage'), async (req, res) => {
  console.log('Received album data:', req.body);
  console.log('Received file:', req.file);

  const { name } = req.body;
  let image_url = null;

  if (!name) {
    return res.status(400).json({ error: 'Tên album là bắt buộc' });
  }

  if (req.file) {
    image_url = 'images/' + req.file.filename;
  }

  let conn;
  try {
    conn = await pool.getConnection();
    const [result] = await conn.query(
      'INSERT INTO albums (name, image_url) VALUES (?, ?)',
      [name, image_url]
    );

    // Lấy album vừa tạo
    const [album] = await conn.query(
      'SELECT * FROM albums WHERE id = ?',
      [result.insertId]
    );

    res.status(201).json(album[0]);
  } catch (error) {
    console.error('Lỗi khi thêm album:', error);
    res.status(500).json({ error: 'Không thể thêm album' });
  } finally {
    if (conn) conn.release();
  }
});

// API cập nhật album
app.put('/api/albums/:id', (req, res) => {
    const { id } = req.params;
    const { name } = req.body;

    if (!name) {
        return res.status(400).json({ error: 'Tên album là bắt buộc' });
    }

    pool.getConnection()
        .then(conn => {
            conn.query('UPDATE albums SET name = ? WHERE id = ?', [name, id])
                .then(([result]) => {
                    if (result.affectedRows === 0) {
                        res.status(404).json({ error: 'Không tìm thấy album' });
                    } else {
                        res.json({ message: 'Cập nhật album thành công' });
                    }
                })
                .catch(err => {
                    console.error('Lỗi khi cập nhật album:', err);
                    res.status(500).json({ error: 'Lỗi khi cập nhật album' });
                })
                .finally(() => {
                    conn.release();
                });
        })
        .catch(err => {
            console.error('Lỗi kết nối database:', err);
            res.status(500).json({ error: 'Lỗi kết nối database' });
        });
});

// API xóa album
app.delete('/api/albums/:id', async (req, res) => {
    const { id } = req.params;
    try {
        await pool.query('DELETE FROM albums WHERE id = ?', [id]);
        res.json({ message: 'Xóa album thành công' });
    } catch (error) {
        console.error('Lỗi khi xóa album:', error);
        res.status(500).json({ error: 'Lỗi server khi xóa album' });
    }
});

// ===================== API Thêm Thể Loại =====================
app.post("/api/genres", (req, res) => {
  const { name, description } = req.body;
  if (!name) {
      return res.status(400).json({ error: "Tên thể loại là bắt buộc" });
  }

  pool.getConnection()
    .then(conn => {
      conn.query("INSERT INTO genres (name, description) VALUES (?, ?)", [name, description || ""])
        .then(result => {
      res.json({ id: result.insertId, name, description });
        })
        .catch(err => {
          console.error('Lỗi khi thêm thể loại:', err);
          return res.status(500).json({ error: err.message });
        });
    })
    .catch(err => {
      console.error('Lỗi kết nối database:', err);
      return res.status(500).json({ error: 'Lỗi kết nối database' });
  });
});

// 📌 API Thêm Ca Sĩ
app.post("/api/artists", async (req, res) => {
  const { name, country, description } = req.body;
  if (!name) {
      return res.status(400).json({ error: "Tên ca sĩ là bắt buộc" });
  }

  try {
      const conn = await pool.getConnection();
      const [result] = await conn.execute(
          'INSERT INTO artists (name, country, description) VALUES (?, ?, ?)',
          [name, country || null, description || null]
      );
      
      conn.release();
      res.json({ 
          id: result.insertId, 
          name, 
          country: country || null, 
          description: description || null 
      });
  } catch (error) {
      console.error('Lỗi khi thêm nghệ sĩ:', error);
      res.status(500).json({ error: 'Không thể thêm nghệ sĩ' });
  }
});

// ===================== API Đăng ký Tài Khoản =====================
// Ví dụ route đăng ký
app.post('/api/register', async (req, res) => {
  console.log('>>> Đã gọi POST /api/register', req.body);
  const { username, email, password } = req.body;
  
  if (!username || !email || !password) {
    return res.status(400).json({ error: 'Thiếu dữ liệu đăng ký' });
  }

  try {
    // Kiểm tra xem user/email đã tồn tại chưa
    const checkUser = 'SELECT * FROM users WHERE username = ? OR email = ?';
    const conn = await pool.getConnection();
    const [results] = await conn.execute(checkUser, [username, email]);

      if (results.length > 0) {
        return res.status(400).json({ error: 'Tên người dùng hoặc email đã tồn tại' });
      }

      // Mã hóa mật khẩu
      const hashedPassword = await bcrypt.hash(password, 10);
      
      // Thêm user mới vào database
      const sql = 'INSERT INTO users (username, email, password) VALUES (?, ?, ?)';
    const [result] = await conn.execute(sql, [username, email, hashedPassword]);

        res.json({ message: 'Đăng ký thành công!' });
  } catch (error) {
    console.error('Lỗi hệ thống:', error);
    res.status(500).json({ error: 'Lỗi hệ thống' });
  }
});

app.post("/api/login", async (req, res) => {
    try {
        console.log('=== Bắt đầu xử lý đăng nhập ===');
        console.log('Request body:', req.body);
        
  const { username, password } = req.body;
        
        if (!username || !password) {
            console.log('Thiếu thông tin đăng nhập');
            return res.status(400).json({ error: "Vui lòng nhập đầy đủ thông tin" });
        }

        console.log('Kiểm tra tài khoản...');
        const [users] = await pool.execute("SELECT * FROM users WHERE username = ?", [username]);
        console.log('Kết quả tìm kiếm:', { found: users.length > 0 });

        if (users.length === 0) {
          return res.status(401).json({ error: "Tài khoản không tồn tại" });
      }

        const user = users[0];
        console.log('Kiểm tra mật khẩu...');

      // Kiểm tra mật khẩu
        const match = await bcrypt.compare(password, user.password);
        console.log('Kết quả kiểm tra mật khẩu:', { match });

          if (!match) {
              return res.status(401).json({ error: "Mật khẩu không đúng" });
          }

        // Tạo JWT token
        const token = jwt.sign({
            userId: user.id,
            username: user.username,
            exp: Math.floor(Date.now() / 1000) + (24 * 60 * 60) // 24 giờ
        }, JWT_SECRET_KEY);

        console.log('=== Đăng nhập thành công ===');
        
        // Trả về thông tin người dùng khi đăng nhập thành công
        res.json({
            message: "Đăng nhập thành công",
            username: user.username,
            userId: user.id,
            token: token
        });
    } catch (error) {
        console.error('Chi tiết lỗi đăng nhập:', {
            message: error.message,
            stack: error.stack,
            code: error.code,
            errno: error.errno
        });
        res.status(500).json({ error: "Lỗi server khi đăng nhập" });
    }
});

// ===================== Route Giao Diện =====================

// Trang chính
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/user.html'));
});

// Trang admin
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/admin.html'));
});

// // API lấy bình luận theo songId
// app.get('/api/comments/:songId', async (req, res) => {
//   const songId = req.params.songId;
//   let conn;
//   try {
//     conn = await pool.getConnection();
//     const [rows] = await conn.query(
//       'SELECT user_id, comment, created_at FROM binhluan WHERE song_id = ?',
//       [songId]
//     );
//     res.json(rows);
//   } catch (err) {
//     console.error('Lỗi lấy bình luận:', err);
//     res.status(500).json({ error: 'Lỗi lấy bình luận' });
//   } finally {
//     if (conn) conn.release();
//   }
// });

// // API thêm bình luận
// app.post('/api/comments', async (req, res) => {
//   const { songId, userId, comment } = req.body;

//   if (!songId || !userId || !comment) {
//       return res.status(400).json({ error: "Thiếu thông tin cần thiết" });
//   }

//   pool.getConnection()
//     .then(conn => {
//       conn.query("SELECT * FROM users WHERE id = ?", [userId])
//         .then(results => {
//           if (results.length === 0) {
//             return res.status(403).json({ error: "Tài khoản không hợp lệ" });
//           }

//           conn.query("INSERT INTO binhluan (song_id, user_id, comment) VALUES (?, ?, ?)", 
//             [songId, userId, comment])
//             .then(() => {
//           res.json({ message: "Bình luận đã được thêm!" });
//             })
//             .catch(err => {
//               console.error('Lỗi khi thêm bình luận:', err);
//               return res.status(500).json({ error: "Lỗi lưu bình luận" });
//             });
//         })
//         .catch(err => {
//           console.error('Lỗi khi kiểm tra tài khoản:', err);
//           return res.status(500).json({ error: "Lỗi kiểm tra tài khoản" });
//         });
//     })
//     .catch(err => {
//       console.error('Lỗi kết nối database:', err);
//       return res.status(500).json({ error: "Lỗi kết nối database" });
//   });
// });

// ===================== API Yêu thích =====================

// API thêm bài hát vào yêu thích
app.post('/api/favorites', authenticateToken, async (req, res) => {
    try {
        console.log('=== Bắt đầu xử lý thêm vào yêu thích ===');
        console.log('Request body:', req.body);
        console.log('User từ token:', req.user);
        
        const { userId, songId } = req.body;
        
        
        // Kiểm tra quyền truy cập
        if (userId !== req.user.userId) {
            console.log('Lỗi quyền truy cập:', {
                requestUserId: userId,
                tokenUserId: req.user.userId
            });
            return res.status(403).json({ error: 'Không có quyền thực hiện thao tác này' });
        }

        // Kiểm tra dữ liệu đầu vào
    if (!userId || !songId) {
            console.log('Thiếu thông tin:', { userId, songId });
        return res.status(400).json({ error: 'Thiếu thông tin người dùng hoặc bài hát' });
    }

        console.log('Kiểm tra user tồn tại...');
        // Kiểm tra user tồn tại
        const [users] = await pool.execute('SELECT id FROM users WHERE id = ?', [userId]);
        console.log('Kết quả kiểm tra user:', users);
        
        if (users.length === 0) {
            return res.status(404).json({ error: 'Không tìm thấy người dùng' });
        }

        console.log('Kiểm tra bài hát tồn tại...');
        // Kiểm tra bài hát tồn tại
        const [songs] = await pool.execute('SELECT id FROM songs WHERE id = ?', [songId]);
        console.log('Kết quả kiểm tra bài hát:', songs);
        
        if (songs.length === 0) {
            return res.status(404).json({ error: 'Không tìm thấy bài hát' });
        }
        
        console.log('Kiểm tra đã tồn tại trong yêu thích...');
        // Kiểm tra xem đã tồn tại trong yêu thích chưa
        const [existing] = await pool.execute(
            'SELECT * FROM favorites WHERE user_id = ? AND song_id = ?',
            [userId, songId]
        );
        console.log('Kết quả kiểm tra tồn tại:', existing);
        
        if (existing.length > 0) {
                return res.status(400).json({ error: 'Bài hát đã có trong danh sách yêu thích' });
            }
        
        console.log('Thêm vào yêu thích...');
        // Thêm vào yêu thích
        await pool.execute(
            'INSERT INTO favorites (user_id, song_id) VALUES (?, ?)',
            [userId, songId]
        );
        
        console.log('=== Thêm vào yêu thích thành công ===');
        res.json({ message: 'Đã thêm vào yêu thích' });
    } catch (error) {
        console.error('Chi tiết lỗi khi thêm vào yêu thích:', {
            message: error.message,
            stack: error.stack,
            code: error.code,
            errno: error.errno
        });
        res.status(500).json({ error: 'Không thể thêm vào yêu thích' });
    }
});

// API lấy danh sách yêu thích
app.get('/api/favorites', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.userId;
        const [rows] = await pool.execute(
            `SELECT s.* FROM songs s
            INNER JOIN favorites f ON s.id = f.song_id
            WHERE f.user_id = ?
            ORDER BY f.created_at DESC`,
            [userId]
        );
        res.json(rows);
    } catch (error) {
        console.error('Lỗi khi lấy danh sách yêu thích:', error);
        res.status(500).json({ error: 'Không thể lấy danh sách yêu thích' });
    }
});

// API xóa bài hát khỏi yêu thích
app.delete('/api/favorites/:songId', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.userId;
        const songId = req.params.songId;
        
        const conn = await pool.getConnection();
        const [result] = await conn.execute(
            'DELETE FROM favorites WHERE user_id = ? AND song_id = ?',
            [userId, songId]
        );
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Không tìm thấy bài hát trong danh sách yêu thích' });
        }
        
        res.json({ message: 'Đã xóa khỏi yêu thích' });
    } catch (error) {
        console.error('Lỗi khi xóa khỏi yêu thích:', error);
        res.status(500).json({ error: 'Không thể xóa khỏi yêu thích' });
    }
});

// API endpoint để lưu timing lyrics
app.post('/api/lyrics/sync', async (req, res) => {
    try {
        const { songId, timestamps } = req.body;
        
        // Kiểm tra dữ liệu đầu vào
        if (!songId || !timestamps || !Array.isArray(timestamps)) {
            return res.status(400).json({ error: 'Dữ liệu không hợp lệ' });
        }

        // Chuyển timestamps thành chuỗi JSON để lưu vào database
        const timestampsJson = JSON.stringify(timestamps);
        
        // Cập nhật timing trong database
        const conn = await pool.getConnection();
        const query = 'UPDATE songs SET timing = ? WHERE id = ?';
        await conn.execute(query, [timestampsJson, songId]);
        
        res.json({ success: true, message: 'Đã lưu timing thành công' });
    } catch (error) {
        console.error('Lỗi khi lưu timing:', error);
        res.status(500).json({ error: 'Lỗi khi lưu timing' });
    }
});

// API tìm kiếm lyrics từ NetEase Music
app.get('/api/search/netease', async (req, res) => {
    try {
        const { title, artist } = req.query;
        // Gọi API của NetEase Music
        const response = await fetch(`http://music.163.com/api/search/pc?s=${encodeURIComponent(title + ' ' + artist)}&type=1`);
        const data = await response.json();
        
        if (data.result && data.result.songs && data.result.songs.length > 0) {
            const songId = data.result.songs[0].id;
            // Lấy lyrics có timing
            const lyricsResponse = await fetch(`http://music.163.com/api/song/lyric?os=pc&id=${songId}&lv=-1&kv=-1&tv=-1`);
            const lyricsData = await lyricsResponse.json();
            
            if (lyricsData.lrc && lyricsData.lrc.lyric) {
                res.json({ lyrics: parseLRC(lyricsData.lrc.lyric) });
            } else {
                res.json({ lyrics: null });
            }
        } else {
            res.json({ lyrics: null });
        }
    } catch (error) {
        console.error('Lỗi khi tìm lyrics từ NetEase:', error);
        res.status(500).json({ error: 'Lỗi khi tìm lyrics' });
    }
});

// API cập nhật lyrics
app.post('/api/lyrics/update', async (req, res) => {
    try {
        const { songId, lyrics } = req.body;
        
        if (!songId || !lyrics) {
            return res.status(400).json({ error: 'Thiếu thông tin cần thiết' });
        }

        // Cập nhật lyrics trong database
        const conn = await pool.getConnection();
        const query = 'UPDATE songs SET lyrics = ?, timing = ? WHERE id = ?';
        const lyricsText = lyrics.map(item => item.text).join('\n');
        const timing = JSON.stringify(lyrics.map(item => item.time));
        
        await conn.execute(query, [lyricsText, timing, songId]);
        
        res.json({ success: true, message: 'Đã cập nhật lyrics thành công' });
    } catch (error) {
        console.error('Lỗi khi cập nhật lyrics:', error);
        res.status(500).json({ error: 'Lỗi khi cập nhật lyrics' });
    }
});

// Hàm parse LRC format
function parseLRC(lrcContent) {
    const lines = lrcContent.split('\n');
    const result = [];
    
    lines.forEach(line => {
        const timeMatch = line.match(/\[(\d{2}):(\d{2})\.(\d{2,3})\]/);
        if (timeMatch) {
            const minutes = parseInt(timeMatch[1]);
            const seconds = parseInt(timeMatch[2]);
            const ms = parseInt(timeMatch[3]);
            const time = minutes * 60 + seconds + ms / 1000;
            
            const text = line.replace(/\[\d{2}:\d{2}\.\d{2,3}\]/, '').trim();
            if (text) {
                result.push({ time, text });
            }
        }
    });
    
    return result.sort((a, b) => a.time - b.time);
}

// API lấy danh sách nghệ sĩ
app.get('/api/artists', async (req, res) => {
    try {
        const conn = await pool.getConnection();
        const [rows] = await conn.execute('SELECT * FROM artists ORDER BY id DESC');
        
        console.log('Dữ liệu artists:', rows);
        conn.release();
        res.json(rows);
    } catch (error) {
        console.error('Lỗi khi lấy danh sách nghệ sĩ:', error);
        res.status(500).json({ error: 'Không thể lấy danh sách nghệ sĩ' });
    }
});

// API cập nhật thông tin nghệ sĩ
app.put('/api/artists/:id', (req, res) => {
    const { id } = req.params;
    const { name, country, description } = req.body;
    if (!name) {
        res.status(400).json({ error: 'Tên nghệ sĩ là bắt buộc' });
        return;
    }

    const query = 'UPDATE artists SET name = ?, country = ?, description = ? WHERE id = ?';
    pool.getConnection()
        .then(conn => {
            conn.query(query, [name, country || null, description || null, id])
                .then(() => {
                    res.json({ message: 'Cập nhật nghệ sĩ thành công' });
                })
                .catch(err => {
                    console.error('Lỗi khi cập nhật nghệ sĩ:', err);
                    res.status(500).json({ error: 'Lỗi server' });
                })
                .finally(() => {
                    conn.release();
                });
        })
        .catch(err => {
            console.error('Lỗi kết nối database:', err);
            res.status(500).json({ error: 'Lỗi kết nối database' });
        });
});

// API xóa nghệ sĩ
app.delete('/api/artists/:id', (req, res) => {
    const { id } = req.params;
    const query = 'DELETE FROM artists WHERE id = ?';
    pool.getConnection()
        .then(conn => {
            conn.query(query, [id])
                .then(() => {
                    res.json({ message: 'Xóa nghệ sĩ thành công' });
                })
                .catch(err => {
                    console.error('Lỗi khi xóa nghệ sĩ:', err);
                    res.status(500).json({ error: 'Lỗi server' });
                })
                .finally(() => {
                    conn.release();
                });
        })
        .catch(err => {
            console.error('Lỗi kết nối database:', err);
            res.status(500).json({ error: 'Lỗi kết nối database' });
        });
});

// ===================== API Genres =====================
app.get('/api/genres', async (req, res) => {
    try {
        const [genres] = await pool.query('SELECT * FROM genres ORDER BY created_at DESC');
        res.json(genres);
    } catch (error) {
        console.error('Lỗi khi lấy danh sách thể loại:', error);
        res.status(500).json({ error: 'Lỗi server khi lấy danh sách thể loại' });
    }
});

app.post('/api/genres', async (req, res) => {
    const { name, description } = req.body;
    if (!name) {
        return res.status(400).json({ error: 'Tên thể loại không được để trống' });
    }

    try {
        const [result] = await pool.query(
            'INSERT INTO genres (name, description) VALUES (?, ?)',
            [name, description || null]
        );
        const [newGenre] = await pool.query('SELECT * FROM genres WHERE id = ?', [result.insertId]);
        res.status(201).json(newGenre[0]);
    } catch (error) {
        console.error('Lỗi khi thêm thể loại:', error);
        res.status(500).json({ error: 'Lỗi server khi thêm thể loại' });
    }
});

app.delete('/api/genres/:id', async (req, res) => {
    const { id } = req.params;
    try {
        await pool.query('DELETE FROM genres WHERE id = ?', [id]);
        res.json({ message: 'Xóa thể loại thành công' });
    } catch (error) {
        console.error('Lỗi khi xóa thể loại:', error);
        res.status(500).json({ error: 'Lỗi server khi xóa thể loại' });
    }
});

// ===================== API Bình luận =====================

// Lấy bình luận theo song_id
app.get('/api/comments/:songId', async (req, res) => {
  const songId = req.params.songId;
  let conn;
  try {
    conn = await pool.getConnection();
    const [rows] = await conn.query(
      `SELECT b.*, u.username 
       FROM binhluan b 
       LEFT JOIN users u ON b.user_id = u.id 
       WHERE b.song_id = ? 
       ORDER BY b.created_at DESC`,
      [songId]
    );
    res.json(rows);
  } catch (err) {
    console.error('Lỗi lấy bình luận:', err);
    res.status(500).json({ error: 'Lỗi lấy bình luận' });
  } finally {
    if (conn) conn.release();
  }
});

// Thêm bình luận mới
app.post('/api/comments', async (req, res) => {
  const { song_id, user_id, comment } = req.body;
  if (!song_id || !comment) {
    return res.status(400).json({ error: 'Thiếu dữ liệu' });
  }
  let conn;
  try {
    conn = await pool.getConnection();
    const [result] = await conn.query(
      'INSERT INTO binhluan (song_id, user_id, comment, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())',
      [song_id, user_id || null, comment]
    );
    res.json({ success: true, id: result.insertId });
  } catch (err) {
    console.error('Lỗi lưu bình luận:', err);
    res.status(500).json({ error: 'Lỗi lưu bình luận' });
  } finally {
    if (conn) conn.release();
  }
});

// ===================== Khởi động Server =====================
app.listen(port, () => {
  console.log(`Server đang chạy trên cổng ${port}`);
});

// Xử lý lỗi toàn cục
app.use((err, req, res, next) => {
  console.error('Lỗi server:', err);
  res.status(500).json({ error: 'Có lỗi xảy ra trên server' });
});
